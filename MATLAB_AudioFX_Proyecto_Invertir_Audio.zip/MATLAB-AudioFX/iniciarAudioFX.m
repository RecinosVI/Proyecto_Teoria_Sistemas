function app = iniciarAudioFX()
%INICIARAUDIOFX Prepara las rutas del proyecto y abre la aplicación nativa.
raiz = fileparts(mfilename('fullpath'));
addpath(fullfile(raiz,'src'), fullfile(raiz,'effects'), ...
    fullfile(raiz,'analysis'), fullfile(raiz,'app'));
app = AudioFX;
if nargout == 0
    clear app
end
end
