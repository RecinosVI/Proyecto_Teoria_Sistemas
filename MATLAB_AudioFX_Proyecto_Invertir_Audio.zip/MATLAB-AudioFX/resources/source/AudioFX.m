classdef AudioFX < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure          matlab.ui.Figure
        MainGrid          matlab.ui.container.GridLayout
        StatusLabel       matlab.ui.control.Label
        BodyGrid          matlab.ui.container.GridLayout
        AnalysisTabs      matlab.ui.container.TabGroup
        TimeTab           matlab.ui.container.Tab
        TimeGrid          matlab.ui.container.GridLayout
        ProcessedAxes     matlab.ui.control.UIAxes
        OriginalAxes      matlab.ui.control.UIAxes
        SpectrumTab       matlab.ui.container.Tab
        SpectrumGrid      matlab.ui.container.GridLayout
        ProcessedFFTAxes  matlab.ui.control.UIAxes
        OriginalFFTAxes   matlab.ui.control.UIAxes
        ControlPanel      matlab.ui.container.Panel
        ControlGrid       matlab.ui.container.GridLayout
        ChainLabel        matlab.ui.control.Label
        ResetButton       matlab.ui.control.Button
        ProcessButton     matlab.ui.control.Button
        SpeedNote         matlab.ui.control.Label
        InvertCheck       matlab.ui.control.CheckBox
        SpeedField        matlab.ui.control.NumericEditField
        SpeedLabel        matlab.ui.control.Label
        OrderField        matlab.ui.control.NumericEditField
        OrderLabel        matlab.ui.control.Label
        Cutoff2Field      matlab.ui.control.NumericEditField
        Cutoff2Label      matlab.ui.control.Label
        CutoffField       matlab.ui.control.NumericEditField
        CutoffLabel       matlab.ui.control.Label
        FilterDropDown    matlab.ui.control.DropDown
        FilterLabel       matlab.ui.control.Label
        FilterCheck       matlab.ui.control.CheckBox
        DriveField        matlab.ui.control.NumericEditField
        DriveLabel        matlab.ui.control.Label
        DistortionCheck   matlab.ui.control.CheckBox
        AlphaField        matlab.ui.control.NumericEditField
        AlphaLabel        matlab.ui.control.Label
        DelayField        matlab.ui.control.NumericEditField
        DelayLabel        matlab.ui.control.Label
        EchoCheck         matlab.ui.control.CheckBox
        GainField         matlab.ui.control.NumericEditField
        GainLabel         matlab.ui.control.Label
        ButtonGrid        matlab.ui.container.GridLayout
        ExportButton      matlab.ui.control.Button
        StopButton        matlab.ui.control.Button
        ResultButton      matlab.ui.control.Button
        OriginalButton    matlab.ui.control.Button
        LoadButton        matlab.ui.control.Button
        FileLabel         matlab.ui.control.Label
        TitleLabel        matlab.ui.control.Label
    end

    properties (Access = private)
        Original = []
        Processed = []
        Fs = 0
        FsOutput = 0
        Player = []
        InputInfo = struct()
        ProcessingInfo = struct()
        RootPath = ''
    end
    methods (Access = public)
        function cargarArchivo(app, ruta)
            % Carga programática y callback comparten el mismo flujo validado.
            [x, fs, info] = cargarAudio(ruta);
            app.detener();
            app.Original = x;
            app.Fs = fs;
            app.InputInfo = info;
            app.Processed = [];
            app.FsOutput = 0;
            app.CutoffField.Value = min(app.CutoffField.Value,fs/4);
            app.Cutoff2Field.Value = min(max(app.Cutoff2Field.Value,fs/3),fs*0.45);
            app.FileLabel.Text = sprintf('%s  |  %g Hz  |  %.3f s  |  %d muestras  |  %d canales', ...
                info.nombre,fs,info.duracion,info.muestras,info.canales);
            app.FileLabel.Tooltip = info.ruta;
            app.OriginalButton.Enable = 'on';
            app.ProcessButton.Enable = 'on';
            app.invalidateResult();
            graficarSenal(x,fs,app.OriginalAxes);
            title(app.OriginalAxes,'Señal original');
            app.drawFFT(x,fs,app.OriginalFFTAxes,'FFT original');
            app.setStatus('Audio cargado. Configure los efectos y pulse Procesar.');
        end
        function [y, fs, info] = procesar(app)
            if isempty(app.Original)
                error('AudioFX:SinAudio','Primero cargue un archivo WAV.');
            end
            app.detener();
            p = app.getParameters();
            [y, fs, info] = procesarCadena(app.Original,app.Fs,p);
            app.Processed = y;
            app.FsOutput = fs;
            app.ProcessingInfo = info;
            graficarSenal(y,fs,app.ProcessedAxes);
            title(app.ProcessedAxes,'Señal procesada');
            app.drawFFT(y,fs,app.ProcessedFFTAxes,'FFT procesada');
            app.ResultButton.Enable = 'on';
            app.ExportButton.Enable = 'on';
            mensaje = sprintf('Procesado  |  %.3f s  |  pico %.4f  |  %d canales', ...
                info.duracionSalida,info.picoSalida,info.canales);
            if info.recorteNecesario
                mensaje = [mensaje '  |  Se normalizará al escuchar o exportar.'];
            end
            app.setStatus(mensaje);
        end
        function info = exportarArchivo(app, ruta)
            if isempty(app.Processed)
                error('AudioFX:SinResultado','Procese el audio antes de exportar.');
            end
            if strcmpi(char(ruta),app.InputInfo.ruta)
                error('AudioFX:ArchivoOriginal','Guarde el resultado con un nombre distinto al archivo original.');
            end
            info = exportarAudio(app.Processed,app.FsOutput,ruta);
            app.setStatus(sprintf('WAV guardado  |  factor de salida %.6f  |  %s', ...
                info.factorAplicado,info.ruta));
        end
        function restablecer(app)
            app.detener();
            p = parametrosPorDefecto();
            app.GainField.Value = p.ganancia;
            app.EchoCheck.Value = p.ecoActivo;
            app.DelayField.Value = p.delaySeg;
            app.AlphaField.Value = p.alpha;
            app.DistortionCheck.Value = p.distorsionActiva;
            app.DriveField.Value = p.intensidad;
            app.FilterCheck.Value = p.filtroActivo;
            app.FilterDropDown.Value = p.tipoFiltro;
            app.CutoffField.Value = p.fc;
            app.Cutoff2Field.Value = 4000;
            if app.Fs > 0
                app.CutoffField.Value = min(p.fc,app.Fs/4);
                app.Cutoff2Field.Value = min(4000,app.Fs*0.4);
            end
            app.OrderField.Value = p.orden;
            app.SpeedField.Value = p.velocidad;
            app.InvertCheck.Value = p.invertirActivo;
            app.updateFilterControls();
            app.invalidateResult();
            app.setStatus('Parámetros restablecidos. Pulse Procesar para obtener el resultado neutro.');
        end
        function detener(app)
            if ~isempty(app.Player) && isvalid(app.Player)
                stop(app.Player);
            end
            app.Player = [];
        end
        function reproducirOriginal(app)
            if isempty(app.Original)
                error('AudioFX:SinAudio','Primero cargue un archivo WAV.');
            end
            app.playSignal(app.Original,app.Fs,'original');
        end
        function reproducirResultado(app)
            if isempty(app.Processed)
                error('AudioFX:SinResultado','Procese el audio antes de reproducir el resultado.');
            end
            app.playSignal(app.Processed,app.FsOutput,'procesado');
        end
    end
    methods (Access = private)
        function p = getParameters(app)
            p = parametrosPorDefecto();
            p.ganancia = app.GainField.Value;
            p.ecoActivo = app.EchoCheck.Value;
            p.delaySeg = app.DelayField.Value;
            p.alpha = app.AlphaField.Value;
            p.distorsionActiva = app.DistortionCheck.Value;
            p.intensidad = app.DriveField.Value;
            p.filtroActivo = app.FilterCheck.Value;
            p.tipoFiltro = app.FilterDropDown.Value;
            p.fc = app.CutoffField.Value;
            if strcmp(p.tipoFiltro,'pasabanda')
                p.fc = [p.fc app.Cutoff2Field.Value];
            end
            p.orden = app.OrderField.Value;
            p.velocidad = app.SpeedField.Value;
            p.invertirActivo = app.InvertCheck.Value;
        end
        function drawFFT(~, x, fs, ax, titulo)
            [f, mag] = calcularFFT(x,fs);
            if size(x,1) == 1
                cla(ax);
                hold(ax,'on');
                for c = 1:size(x,2)
                    plot(ax,f,mag(:,c),'o','LineWidth',1);
                end
                hold(ax,'off');
            else
                plot(ax,f,mag,'LineWidth',1);
            end
            ax.Visible = 'on';
            title(ax,titulo);
            xlabel(ax,'Frecuencia (Hz)');
            ylabel(ax,'Magnitud de amplitud');
            grid(ax,'on');
            xlim(ax,[0 fs/2]);
            nombres = arrayfun(@(c)sprintf('Canal %d',c),1:size(x,2),'UniformOutput',false);
            legend(ax,nombres,'Location','northeast');
        end
        function invalidateResult(app)
            app.Processed = [];
            app.FsOutput = 0;
            app.ResultButton.Enable = 'off';
            app.ExportButton.Enable = 'off';
            cla(app.ProcessedAxes);
            cla(app.ProcessedFFTAxes);
            title(app.ProcessedAxes,'Señal procesada');
            title(app.ProcessedFFTAxes,'FFT procesada');
        end
        function updateFilterControls(app)
            if strcmp(app.FilterDropDown.Value,'pasabanda')
                app.Cutoff2Field.Enable = 'on';
                app.CutoffLabel.Text = 'Corte inferior (Hz)';
            else
                app.Cutoff2Field.Enable = 'off';
                app.CutoffLabel.Text = 'Frecuencia de corte (Hz)';
            end
        end
        function setStatus(app, mensaje)
            app.StatusLabel.Text = mensaje;
            app.StatusLabel.Tooltip = mensaje;
            drawnow limitrate;
        end
        function showError(app, causa)
            app.setStatus(['Operación cancelada: ' causa.message]);
            uialert(app.UIFigure,causa.message,'MATLAB AudioFX','Icon','error');
        end
        function playSignal(app, x, fs, nombre)
            app.detener();
            [segura,factor] = prepararSalida(x);
            try
                app.Player = audioplayer(segura,fs);
                play(app.Player);
            catch causa
                error('AudioFX:Reproduccion','No se pudo reproducir el audio. Compruebe el dispositivo y los canales: %s',causa.message);
            end
            app.setStatus(sprintf('Reproduciendo audio %s  |  factor seguro %.6f',nombre,factor));
        end
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function startupFcn(app)
            for eje = [app.OriginalAxes app.ProcessedAxes app.OriginalFFTAxes app.ProcessedFFTAxes]
                eje.Visible = 'on';
            end
            ubicacion = which('parametrosPorDefecto');
            if ~isempty(ubicacion)
                app.RootPath = fileparts(fileparts(ubicacion));
            else
                app.RootPath = fileparts(fileparts(mfilename('fullpath')));
            end
            addpath(fullfile(app.RootPath,'src'),fullfile(app.RootPath,'effects'),fullfile(app.RootPath,'analysis'));
            app.restablecer();
            app.setStatus('Cargue un archivo WAV para comenzar. Los efectos se aplican al audio original.');
        end

        % Button pushed function: LoadButton
        function LoadButtonPushed(app, event)
            [nombre,carpeta] = uigetfile({'*.wav','Audio WAV (*.wav)'}, ...
                'Cargar audio',fullfile(app.RootPath,'audio'));
            if isequal(nombre,0), return; end
            try
                app.cargarArchivo(fullfile(carpeta,nombre));
            catch causa
                app.showError(causa);
            end
        end

        % Button pushed function: ProcessButton
        function ProcessButtonPushed(app, event)
            try
                app.procesar();
            catch causa
                app.invalidateResult();
                app.showError(causa);
            end
        end

        % Button pushed function: ResetButton
        function ResetButtonPushed(app, event)
            app.restablecer();
        end

        % Button pushed function: ExportButton
        function ExportButtonPushed(app, event)
            if isempty(app.Processed), return; end
            [~,base] = fileparts(app.InputInfo.nombre);
            [nombre,carpeta] = uiputfile({'*.wav','Audio WAV (*.wav)'}, ...
                'Exportar señal procesada',fullfile(app.RootPath,'audio',[base '_procesado.wav']));
            if isequal(nombre,0), return; end
            [~,~,extension] = fileparts(nombre);
            if isempty(extension), nombre = [nombre '.wav']; end
            try
                app.exportarArchivo(fullfile(carpeta,nombre));
            catch causa
                app.showError(causa);
            end
        end

        % Button pushed function: OriginalButton
        function OriginalButtonPushed(app, event)
            try
                app.reproducirOriginal();
            catch causa
                app.showError(causa);
            end
        end

        % Button pushed function: ResultButton
        function ResultButtonPushed(app, event)
            try
                app.reproducirResultado();
            catch causa
                app.showError(causa);
            end
        end

        % Button pushed function: StopButton
        function StopButtonPushed(app, event)
            app.detener();
            app.setStatus('Reproducción detenida.');
        end

        % Value changed function: AlphaField, Cutoff2Field, CutoffField, 
        % ...and 9 other components
        function ParameterChanged(app, event)
            app.detener();
            app.updateFilterControls();
            app.invalidateResult();
            app.setStatus('Parámetros modificados. Pulse Procesar para actualizar el resultado.');
        end

        % Close request function: UIFigure
        function CloseRequested(app, event)
            app.detener();
            delete(app);
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Color = [0.96 0.97 0.98];
            app.UIFigure.Position = [80 60 1240 820];
            app.UIFigure.Name = 'MATLAB AudioFX';
            app.UIFigure.CloseRequestFcn = createCallbackFcn(app, @CloseRequested, true);

            % Create MainGrid
            app.MainGrid = uigridlayout(app.UIFigure);
            app.MainGrid.ColumnWidth = {'1x'};
            app.MainGrid.RowHeight = {34, 30, 42, '1x', 46};
            app.MainGrid.RowSpacing = 8;
            app.MainGrid.Padding = [18 14 18 14];

            % Create TitleLabel
            app.TitleLabel = uilabel(app.MainGrid);
            app.TitleLabel.FontSize = 24;
            app.TitleLabel.FontWeight = 'bold';
            app.TitleLabel.FontColor = [0.1 0.2 0.32];
            app.TitleLabel.Layout.Row = 1;
            app.TitleLabel.Layout.Column = 1;
            app.TitleLabel.Text = 'MATLAB AudioFX';

            % Create FileLabel
            app.FileLabel = uilabel(app.MainGrid);
            app.FileLabel.FontSize = 13;
            app.FileLabel.Layout.Row = 2;
            app.FileLabel.Layout.Column = 1;
            app.FileLabel.Text = 'Ningún archivo cargado';

            % Create ButtonGrid
            app.ButtonGrid = uigridlayout(app.MainGrid);
            app.ButtonGrid.ColumnWidth = {'1x', '1x', '1x', 110, '1x'};
            app.ButtonGrid.RowHeight = {'1x'};
            app.ButtonGrid.Padding = [0 0 0 0];
            app.ButtonGrid.Layout.Row = 3;
            app.ButtonGrid.Layout.Column = 1;

            % Create LoadButton
            app.LoadButton = uibutton(app.ButtonGrid, 'push');
            app.LoadButton.ButtonPushedFcn = createCallbackFcn(app, @LoadButtonPushed, true);
            app.LoadButton.Layout.Row = 1;
            app.LoadButton.Layout.Column = 1;
            app.LoadButton.Text = 'Cargar WAV';

            % Create OriginalButton
            app.OriginalButton = uibutton(app.ButtonGrid, 'push');
            app.OriginalButton.ButtonPushedFcn = createCallbackFcn(app, @OriginalButtonPushed, true);
            app.OriginalButton.Enable = 'off';
            app.OriginalButton.Layout.Row = 1;
            app.OriginalButton.Layout.Column = 2;
            app.OriginalButton.Text = 'Escuchar original';

            % Create ResultButton
            app.ResultButton = uibutton(app.ButtonGrid, 'push');
            app.ResultButton.ButtonPushedFcn = createCallbackFcn(app, @ResultButtonPushed, true);
            app.ResultButton.Enable = 'off';
            app.ResultButton.Layout.Row = 1;
            app.ResultButton.Layout.Column = 3;
            app.ResultButton.Text = 'Escuchar resultado';

            % Create StopButton
            app.StopButton = uibutton(app.ButtonGrid, 'push');
            app.StopButton.ButtonPushedFcn = createCallbackFcn(app, @StopButtonPushed, true);
            app.StopButton.Layout.Row = 1;
            app.StopButton.Layout.Column = 4;
            app.StopButton.Text = 'Detener';

            % Create ExportButton
            app.ExportButton = uibutton(app.ButtonGrid, 'push');
            app.ExportButton.ButtonPushedFcn = createCallbackFcn(app, @ExportButtonPushed, true);
            app.ExportButton.Enable = 'off';
            app.ExportButton.Layout.Row = 1;
            app.ExportButton.Layout.Column = 5;
            app.ExportButton.Text = 'Exportar WAV';

            % Create BodyGrid
            app.BodyGrid = uigridlayout(app.MainGrid);
            app.BodyGrid.ColumnWidth = {340, '1x'};
            app.BodyGrid.RowHeight = {'1x'};
            app.BodyGrid.ColumnSpacing = 14;
            app.BodyGrid.Padding = [0 0 0 0];
            app.BodyGrid.Layout.Row = 4;
            app.BodyGrid.Layout.Column = 1;

            % Create ControlPanel
            app.ControlPanel = uipanel(app.BodyGrid);
            app.ControlPanel.Title = 'Configurar efectos';
            app.ControlPanel.Layout.Row = 1;
            app.ControlPanel.Layout.Column = 1;
            app.ControlPanel.FontWeight = 'bold';

            % Create ControlGrid
            app.ControlGrid = uigridlayout(app.ControlPanel);
            app.ControlGrid.ColumnWidth = {'1x', 100};
            app.ControlGrid.RowHeight = {28, 26, 28, 28, 26, 28, 26, 28, 28, 28, 28, 28, 36, 26, 34, 34, 48, '1x'};
            app.ControlGrid.RowSpacing = 5;
            app.ControlGrid.Padding = [12 8 12 8];

            % Create GainLabel
            app.GainLabel = uilabel(app.ControlGrid);
            app.GainLabel.Layout.Row = 1;
            app.GainLabel.Layout.Column = 1;
            app.GainLabel.Text = 'Ganancia A';

            % Create GainField
            app.GainField = uieditfield(app.ControlGrid, 'numeric');
            app.GainField.Limits = [0 20];
            app.GainField.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.GainField.Tooltip = 'y[n] = A x[n]';
            app.GainField.Layout.Row = 1;
            app.GainField.Layout.Column = 2;
            app.GainField.Value = 1;

            % Create EchoCheck
            app.EchoCheck = uicheckbox(app.ControlGrid);
            app.EchoCheck.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.EchoCheck.Text = 'Activar eco';
            app.EchoCheck.Layout.Row = 2;
            app.EchoCheck.Layout.Column = [1 2];

            % Create DelayLabel
            app.DelayLabel = uilabel(app.ControlGrid);
            app.DelayLabel.Layout.Row = 3;
            app.DelayLabel.Layout.Column = 1;
            app.DelayLabel.Text = 'Retardo (segundos)';

            % Create DelayField
            app.DelayField = uieditfield(app.ControlGrid, 'numeric');
            app.DelayField.Limits = [0 5];
            app.DelayField.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.DelayField.Layout.Row = 3;
            app.DelayField.Layout.Column = 2;
            app.DelayField.Value = 0.25;

            % Create AlphaLabel
            app.AlphaLabel = uilabel(app.ControlGrid);
            app.AlphaLabel.Layout.Row = 4;
            app.AlphaLabel.Layout.Column = 1;
            app.AlphaLabel.Text = 'Intensidad del eco α';

            % Create AlphaField
            app.AlphaField = uieditfield(app.ControlGrid, 'numeric');
            app.AlphaField.Limits = [0 1];
            app.AlphaField.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.AlphaField.Layout.Row = 4;
            app.AlphaField.Layout.Column = 2;
            app.AlphaField.Value = 0.35;

            % Create DistortionCheck
            app.DistortionCheck = uicheckbox(app.ControlGrid);
            app.DistortionCheck.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.DistortionCheck.Text = 'Activar distorsión';
            app.DistortionCheck.Layout.Row = 5;
            app.DistortionCheck.Layout.Column = [1 2];

            % Create DriveLabel
            app.DriveLabel = uilabel(app.ControlGrid);
            app.DriveLabel.Layout.Row = 6;
            app.DriveLabel.Layout.Column = 1;
            app.DriveLabel.Text = 'Intensidad G';

            % Create DriveField
            app.DriveField = uieditfield(app.ControlGrid, 'numeric');
            app.DriveField.Limits = [0.1 30];
            app.DriveField.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.DriveField.Tooltip = 'y[n] = tanh(G x[n])';
            app.DriveField.Layout.Row = 6;
            app.DriveField.Layout.Column = 2;
            app.DriveField.Value = 2;

            % Create FilterCheck
            app.FilterCheck = uicheckbox(app.ControlGrid);
            app.FilterCheck.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.FilterCheck.Text = 'Activar filtro';
            app.FilterCheck.Layout.Row = 7;
            app.FilterCheck.Layout.Column = [1 2];

            % Create FilterLabel
            app.FilterLabel = uilabel(app.ControlGrid);
            app.FilterLabel.Layout.Row = 8;
            app.FilterLabel.Layout.Column = 1;
            app.FilterLabel.Text = 'Tipo de filtro';

            % Create FilterDropDown
            app.FilterDropDown = uidropdown(app.ControlGrid);
            app.FilterDropDown.Items = {'Pasa bajos', 'Pasa altos', 'Pasa banda'};
            app.FilterDropDown.ItemsData = {'pasabajos', 'pasaaltos', 'pasabanda'};
            app.FilterDropDown.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.FilterDropDown.Layout.Row = 8;
            app.FilterDropDown.Layout.Column = 2;
            app.FilterDropDown.Value = 'pasabajos';

            % Create CutoffLabel
            app.CutoffLabel = uilabel(app.ControlGrid);
            app.CutoffLabel.Layout.Row = 9;
            app.CutoffLabel.Layout.Column = 1;
            app.CutoffLabel.Text = 'Frecuencia de corte (Hz)';

            % Create CutoffField
            app.CutoffField = uieditfield(app.ControlGrid, 'numeric');
            app.CutoffField.Limits = [0 Inf];
            app.CutoffField.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.CutoffField.Tooltip = 'Debe cumplir 0 < Fc < Fs/2';
            app.CutoffField.Layout.Row = 9;
            app.CutoffField.Layout.Column = 2;
            app.CutoffField.Value = 1000;

            % Create Cutoff2Label
            app.Cutoff2Label = uilabel(app.ControlGrid);
            app.Cutoff2Label.Layout.Row = 10;
            app.Cutoff2Label.Layout.Column = 1;
            app.Cutoff2Label.Text = 'Corte superior (Hz)';

            % Create Cutoff2Field
            app.Cutoff2Field = uieditfield(app.ControlGrid, 'numeric');
            app.Cutoff2Field.Limits = [0 Inf];
            app.Cutoff2Field.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.Cutoff2Field.Enable = 'off';
            app.Cutoff2Field.Layout.Row = 10;
            app.Cutoff2Field.Layout.Column = 2;
            app.Cutoff2Field.Value = 4000;

            % Create OrderLabel
            app.OrderLabel = uilabel(app.ControlGrid);
            app.OrderLabel.Layout.Row = 11;
            app.OrderLabel.Layout.Column = 1;
            app.OrderLabel.Text = 'Orden Butterworth';

            % Create OrderField
            app.OrderField = uieditfield(app.ControlGrid, 'numeric');
            app.OrderField.Limits = [1 10];
            app.OrderField.RoundFractionalValues = 'on';
            app.OrderField.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.OrderField.Layout.Row = 11;
            app.OrderField.Layout.Column = 2;
            app.OrderField.Value = 4;

            % Create SpeedLabel
            app.SpeedLabel = uilabel(app.ControlGrid);
            app.SpeedLabel.Layout.Row = 12;
            app.SpeedLabel.Layout.Column = 1;
            app.SpeedLabel.Text = 'Factor de velocidad';

            % Create SpeedField
            app.SpeedField = uieditfield(app.ControlGrid, 'numeric');
            app.SpeedField.Limits = [0.25 4];
            app.SpeedField.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.SpeedField.Layout.Row = 12;
            app.SpeedField.Layout.Column = 2;
            app.SpeedField.Value = 1;

            % Create SpeedNote
            app.SpeedNote = uilabel(app.ControlGrid);
            app.SpeedNote.WordWrap = 'on';
            app.SpeedNote.FontSize = 11;
            app.SpeedNote.Layout.Row = 13;
            app.SpeedNote.Layout.Column = [1 2];
            app.SpeedNote.Text = 'Remuestreo con Fs fija. Cambia duración y tono.';

            % Create InvertCheck
            app.InvertCheck = uicheckbox(app.ControlGrid);
            app.InvertCheck.Text = 'Invertir audio';
            app.InvertCheck.Tooltip = 'Reproduce las muestras desde el final al inicio, conservando los canales.';
            app.InvertCheck.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);
            app.InvertCheck.Layout.Row = 14;
            app.InvertCheck.Layout.Column = [1 2];

            % Create ProcessButton
            app.ProcessButton = uibutton(app.ControlGrid, 'push');
            app.ProcessButton.ButtonPushedFcn = createCallbackFcn(app, @ProcessButtonPushed, true);
            app.ProcessButton.BackgroundColor = [0.1 0.31 0.5];
            app.ProcessButton.FontWeight = 'bold';
            app.ProcessButton.FontColor = [1 1 1];
            app.ProcessButton.Enable = 'off';
            app.ProcessButton.Layout.Row = 15;
            app.ProcessButton.Layout.Column = [1 2];
            app.ProcessButton.Text = 'Procesar';

            % Create ResetButton
            app.ResetButton = uibutton(app.ControlGrid, 'push');
            app.ResetButton.ButtonPushedFcn = createCallbackFcn(app, @ResetButtonPushed, true);
            app.ResetButton.Layout.Row = 16;
            app.ResetButton.Layout.Column = [1 2];
            app.ResetButton.Text = 'Restablecer parámetros';

            % Create ChainLabel
            app.ChainLabel = uilabel(app.ControlGrid);
            app.ChainLabel.WordWrap = 'on';
            app.ChainLabel.FontSize = 11;
            app.ChainLabel.Layout.Row = 17;
            app.ChainLabel.Layout.Column = [1 2];
            app.ChainLabel.Text = 'Orden: ganancia → eco → distorsión → filtro → velocidad → invertir';

            % Create AnalysisTabs
            app.AnalysisTabs = uitabgroup(app.BodyGrid);
            app.AnalysisTabs.Layout.Row = 1;
            app.AnalysisTabs.Layout.Column = 2;

            % Create TimeTab
            app.TimeTab = uitab(app.AnalysisTabs);
            app.TimeTab.Title = 'Señales en el tiempo';

            % Create TimeGrid
            app.TimeGrid = uigridlayout(app.TimeTab);
            app.TimeGrid.ColumnWidth = {'1x'};

            % Create OriginalAxes
            app.OriginalAxes = uiaxes(app.TimeGrid);
            title(app.OriginalAxes, 'Señal original')
            xlabel(app.OriginalAxes, 'Tiempo (s)')
            ylabel(app.OriginalAxes, 'Amplitud')
            app.OriginalAxes.Layout.Row = 1;
            app.OriginalAxes.Layout.Column = 1;

            % Create ProcessedAxes
            app.ProcessedAxes = uiaxes(app.TimeGrid);
            title(app.ProcessedAxes, 'Señal procesada')
            xlabel(app.ProcessedAxes, 'Tiempo (s)')
            ylabel(app.ProcessedAxes, 'Amplitud')
            app.ProcessedAxes.Layout.Row = 2;
            app.ProcessedAxes.Layout.Column = 1;

            % Create SpectrumTab
            app.SpectrumTab = uitab(app.AnalysisTabs);
            app.SpectrumTab.Title = 'Análisis FFT';

            % Create SpectrumGrid
            app.SpectrumGrid = uigridlayout(app.SpectrumTab);
            app.SpectrumGrid.ColumnWidth = {'1x'};

            % Create OriginalFFTAxes
            app.OriginalFFTAxes = uiaxes(app.SpectrumGrid);
            title(app.OriginalFFTAxes, 'FFT original')
            xlabel(app.OriginalFFTAxes, 'Frecuencia (Hz)')
            ylabel(app.OriginalFFTAxes, 'Magnitud')
            app.OriginalFFTAxes.Layout.Row = 1;
            app.OriginalFFTAxes.Layout.Column = 1;

            % Create ProcessedFFTAxes
            app.ProcessedFFTAxes = uiaxes(app.SpectrumGrid);
            title(app.ProcessedFFTAxes, 'FFT procesada')
            xlabel(app.ProcessedFFTAxes, 'Frecuencia (Hz)')
            ylabel(app.ProcessedFFTAxes, 'Magnitud')
            app.ProcessedFFTAxes.Layout.Row = 2;
            app.ProcessedFFTAxes.Layout.Column = 1;

            % Create StatusLabel
            app.StatusLabel = uilabel(app.MainGrid);
            app.StatusLabel.BackgroundColor = [0.91 0.94 0.96];
            app.StatusLabel.WordWrap = 'on';
            app.StatusLabel.Tooltip = 'Cargue un archivo WAV para comenzar. Los efectos se aplican al audio original.';
            app.StatusLabel.Layout.Row = 5;
            app.StatusLabel.Layout.Column = 1;
            app.StatusLabel.Text = 'Cargue un archivo WAV para comenzar. Los efectos se aplican al audio original.';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = AudioFX

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @startupFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end