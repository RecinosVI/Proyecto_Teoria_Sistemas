function lineas = graficarSenal(x, Fs, ax)
%GRAFICARSENAL Grafica cada canal en tiempo con origen t=0.
%   LINEAS = GRAFICARSENAL(X,FS,AX) acepta ejes normales o UIAxes. Si AX
%   se omite usa GCA. Sustituye el gráfico anterior para no acumular trazas.

x = validarAudio(x);
if ~isnumeric(Fs) || ~isscalar(Fs) || ~isreal(Fs) || ~isfinite(Fs) || Fs <= 0
    error('AudioFX:FrecuenciaMuestreoInvalida', 'Fs debe ser un escalar real positivo y finito.');
end
if nargin < 3 || isempty(ax)
    ax = gca;
end
if ~isscalar(ax) || ~isgraphics(ax) || ...
        ~(isa(ax, 'matlab.graphics.axis.Axes') || isa(ax, 'matlab.ui.control.UIAxes'))
    error('AudioFX:EjesInvalidos', 'El destino debe ser un objeto de ejes o UIAxes válido.');
end
t = (0:size(x, 1)-1).' ./ double(Fs);
cla(ax);
hold(ax, 'off');
if size(x, 1) == 1
    % PLOT trataría una fila NxC como una única secuencia de C puntos.
    % Cada canal recibe su propia línea, incluso con una sola muestra.
    lineas = gobjects(size(x, 2), 1);
    for canal = 1:size(x, 2)
        lineas(canal) = plot(ax, t, x(:, canal), 'o', 'LineWidth', 0.8);
        hold(ax, 'on');
    end
    hold(ax, 'off');
else
    lineas = plot(ax, t, x, 'LineWidth', 0.8);
end
% App Designer puede ocultar los UIAxes vacíos al reconstruir el archivo.
% Al existir datos, la vista debe quedar explícitamente visible.
ax.Visible = 'on';
xlabel(ax, 'Tiempo (s)');
ylabel(ax, 'Amplitud');
grid(ax, 'on');
end
