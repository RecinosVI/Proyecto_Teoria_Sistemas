function [f, magnitud] = calcularFFT(x, Fs)
%CALCULARFFT Espectro de amplitud unilateral por canal sin ventana.
%   F es un vector columna en Hz; MAGNITUD tiene floor(N/2)+1 filas y C
%   columnas. Primero se divide abs(fft(X)) entre N. Se doblan solamente
%   los bins de frecuencia positiva con pareja negativa: nunca DC ni el
%   bin de Nyquist (que existe únicamente cuando N es par).
%   Una sinusoide que coincide con un bin revela su amplitud de pico. La
%   ausencia de ventana conserva la interpretación básica; señales que
%   no completan períodos enteros presentan fuga espectral.

x = validarAudio(x);
if ~isnumeric(Fs) || ~isscalar(Fs) || ~isreal(Fs) || ~isfinite(Fs) || Fs <= 0
    error('AudioFX:FrecuenciaMuestreoInvalida', 'Fs debe ser un escalar real positivo y finito.');
end
N = size(x, 1);
numeroBins = floor(N / 2) + 1;
espectro = fft(x, [], 1);
magnitud = abs(espectro(1:numeroBins, :)) ./ N;
if rem(N, 2) == 0
    magnitud(2:end-1, :) = 2 .* magnitud(2:end-1, :);
else
    magnitud(2:end, :) = 2 .* magnitud(2:end, :);
end
f = (0:numeroBins-1).' .* (double(Fs) / N);
if any(~isfinite(magnitud), 'all')
    error('AudioFX:ResultadoNoFinito', 'La FFT produce valores fuera del rango numérico.');
end
end
