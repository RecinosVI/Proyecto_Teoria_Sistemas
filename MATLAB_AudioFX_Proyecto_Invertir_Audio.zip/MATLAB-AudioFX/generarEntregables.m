function informe = generarEntregables()
%GENERARENTREGABLES Genera y verifica los artefactos nativos en MATLAB R2026b.
% Ejecute desde esta carpeta con una licencia disponible. No publica GitHub.
raiz = fileparts(mfilename('fullpath'));
addpath(raiz,fullfile(raiz,'src'),fullfile(raiz,'effects'), ...
    fullfile(raiz,'analysis'),fullfile(raiz,'tests'));
informe = struct('estado','iniciado','fecha',char(datetime('now')), ...
    'MATLAB',version,'appNativa',false,'proyectoNativo',false, ...
    'pruebas',false,'interfaz',false,'demostracion',false,'audicion','pendiente', ...
    'GitHub','pendiente');
archivo = fullfile(raiz,'docs','verificacion_matlab.json');
try
    disp('1 de 5: ejecutar pruebas de procesamiento, FFT y archivos WAV');
    resultados = run_tests();
    informe.pruebas = all([resultados.Passed]);
    informe.numeroPruebas = numel(resultados);
    disp('2 de 5: verificar la interfaz con carga, procesamiento y exportación');
    gui = verificarApp();
    informe.interfaz = true;
    informe.resultadoInterfaz = gui;
    disp('3 de 5: crear y validar el archivo App Designer nativo');
    nativa = buildAppDesigner(raiz);
    informe.appNativa = isfile(nativa.AppFile);
    guiNativa = verificarApp();
    informe.verificacionInterfazNativa = guiNativa;
    disp('4 de 5: generar WAV procesado y gráficas con MATLAB');
    demo = generarDemostracion();
    informe.demostracion = true;
    informe.datosDemostracion = demo;
    disp('5 de 5: guardar MATLAB Project');
    proyecto = buildProject(raiz);
    informe.proyectoNativo = isfile(proyecto);
    informe.estado = 'generado y verificado sin audicion ni publicacion';
    escribirInforme(archivo,informe);
    fprintf('\nArtefactos generados y pruebas superadas.\nApp: %s\nProyecto: %s\n', ...
        nativa.AppFile,proyecto);
    disp('Para abrir: iniciarAudioFX. Revise la audición y la publicación según docs.');
catch causa
    informe.estado = 'interrumpido';
    informe.error = causa.message;
    informe.identificadorError = causa.identifier;
    escribirInforme(archivo,informe);
    rethrow(causa);
end
end

function escribirInforme(ruta,informe)
fid = fopen(ruta,'w','n','UTF-8');
if fid < 0
    warning('AudioFX:Informe','No se pudo escribir el informe de verificación.');
    return;
end
limpieza = onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'%s',jsonencode(informe,'PrettyPrint',true));
end
