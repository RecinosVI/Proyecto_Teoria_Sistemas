# Arquitectura y contratos técnicos

## Separación de responsabilidades

La interfaz de App Designer es la capa de presentación. Conserva el audio original, el resultado, la frecuencia de muestreo, los parámetros y el reproductor. Sus callbacks leen controles, validan disponibilidad, invocan módulos y actualizan las vistas. El procesamiento matemático se mantiene en funciones `.m` independientes.

La estructura sigue la especificación: `src/` contiene la coordinación; `effects/`, las transformaciones; `analysis/`, el análisis y las gráficas; `audio/`, las señales de prueba; `app/`, la interfaz; `tests/`, las pruebas; `docs/`, la documentación; y `resources/`, los recursos y resultados de apoyo. La aplicación nativa se entrega en `app/AudioFX.mlapp` y su fuente de respaldo en `resources/source/AudioFX.m`, fuera del MATLAB Path. El proyecto `MATLAB-AudioFX.prj` y sus metadatos están incluidos. `generarEntregables` permite regenerar estos artefactos en MATLAB R2026b.

```text
WAV ── cargarAudio / audioread ──► x, Fs
                                   │
                             procesarCadena
                                   │
             ganancia → eco → distorsión → filtro → velocidad → invertir
                                   │
                                   ▼
                                 y, FsSalida
                                   │
              ┌────────────────────┼─────────────────────┐
          gráficas/FFT       prepararSalida         exportarAudio
                                audioplayer            audiowrite
```

## Representación del audio

El contrato común es una matriz real, finita y no vacía de tamaño `N × C`, con una muestra por fila y un canal por columna. `Fs` es un escalar real positivo en Hz. Los índices de MATLAB comienzan en 1; las ecuaciones de sistemas utilizan `n = 0, …, N−1`. El eje temporal es `(0:N-1)'/Fs` y la duración del bloque es `N/Fs`.

El último instante representado es `(N−1)/Fs`; no debe confundirse con la duración total. No se mezclan los canales al procesar ni se normalizan por separado. Las operaciones de reproducción están sujetas a los canales admitidos por el dispositivo de audio.

## API de efectos y análisis

| Función | Entrada / salida | Contrato |
|---|---|---|
| `aplicarGanancia(x,A)` | `y` | `y = A*x`; `A` escalar real finito. Preserva tamaño. |
| `aplicarEco(x,Fs,delaySeg,alpha)` | `y` | `delaySeg ≥ 0`, `0 ≤ alpha ≤ 1`; conserva `N+D` filas con `D = round(Fs*delaySeg)`. |
| `aplicarDistorsion(x,G)` | `y` | `G > 0`; `y = tanh(G*x)`; preserva tamaño. |
| `aplicarFiltro(x,Fs,tipo,fc,orden)` | `y` | Orden entero positivo, predeterminado 4; usa `butter`, `zp2sos` y `filter` por sección, estado inicial cero. |
| `cambiarVelocidad(x,Fs,factor)` | `[y,FsSalida]` | Factor positivo; remuestreo a razón inversa; `FsSalida = Fs`; identidad exacta cuando factor es 1. |
| `calcularFFT(x,Fs)` | `[f,magnitud]` | Eje columna en Hz y magnitud unilateral por canal, con `floor(N/2)+1` filas. |

Los tipos canónicos de filtro son `'pasabajos'`, `'pasaaltos'` y `'pasabanda'`. La banda utiliza un vector `[fcInferior fcSuperior]`. Todos los cortes cumplen `0 < fc < Fs/2`, y la banda exige orden creciente. Los alias ingleses disponibles están documentados en la ayuda de `aplicarFiltro`.

## Parámetros de la cadena

`parametrosPorDefecto()` devuelve:

```matlab
p.ganancia = 1;
p.ecoActivo = false;
p.delaySeg = 0.25;
p.alpha = 0.35;
p.distorsionActiva = false;
p.intensidad = 2;
p.filtroActivo = false;
p.tipoFiltro = 'pasabajos';
p.fc = 1000;
p.orden = 4;
p.velocidad = 1;
```

`[y,FsSalida,info] = procesarCadena(x,Fs,p)` aplica las etapas en orden fijo. Ganancia y velocidad siempre tienen un valor; los otros cuatro módulos se activan mediante banderas. La salida incluye `picoEntrada`, `picoSalida`, `muestrasEntrada`, `muestrasSalida`, `canales`, `duracionEntrada`, `duracionSalida`, `recorteNecesario`, `parametros` y `ordenCadena`.

El orden importa: por ejemplo, distorsionar después de ganar amplitud puede generar armónicos, mientras que ganar amplitud después de distorsionar solo escala los armónicos existentes. Cada pulsación de Procesar utiliza el original, evitando sumar efectos de procesamientos previos involuntariamente.

## Carga, salida y clipping

`[x,Fs,info] = cargarAudio(ruta)` lee WAV y devuelve `ruta`, `nombre`, `Fs`, `muestras`, `canales`, `duracion` y `pico`. La validez matemática de los datos se comprueba además de la lectura del archivo.

`[z,factor,pico] = prepararSalida(y)` calcula `pico = max(abs(y(:)))`. Si `pico > 1`, aplica `factor = 1/pico` a toda la matriz. En otro caso, usa `factor = 1`, incluido el silencio. No introduce divisiones por cero ni eleva señales débiles.

`info = exportarAudio(y,FsSalida,ruta)` utiliza esa protección y escribe WAV PCM24. Devuelve `ruta`, `Fs`, `muestras`, `canales`, `picoOriginal`, `factorAplicado` y `normalizado`. La cuantización impide esperar igualdad bit a bit entre la matriz original en coma flotante y el WAV vuelto a leer.

## Validación y pruebas

Las funciones rechazan matrices vacías, complejas o no finitas y parámetros inválidos. La aplicación comprueba además que haya una señal cargada y muestra errores de operación. Los módulos mantienen su propia validación para que también sean seguros al usarse por consola.

Las 44 pruebas automatizadas son funciones locales agrupadas mediante [functiontests](https://www.mathworks.com/help/matlab/ref/functiontests.html). Usan impulsos, tonos deterministas y archivos temporales. Comprueban amplitudes, retardo, cola, rechazo de bandas, canales, escala de FFT, remuestreo, clipping y round-trip WAV. Todas aprobaron en MATLAB R2026b. Se ejecutaron además 27 comprobaciones de la interfaz fuente, 29 de la app nativa y 17 de callbacks y reproducción técnica. Los informes JSON conservan los resultados. La carga y la exportación se recorrieron además con sus cuadros de diálogo reales; la valoración auditiva humana y las cancelaciones de diálogos se identifican por separado en el protocolo y el registro.

## Control de versiones

El repositorio local contiene código, recursos de prueba y documentación. Los archivos temporales, cachés y productos regenerables se excluyen mediante `.gitignore` cuando corresponda. Publicar en GitHub requiere un repositorio remoto y acceso autorizado a la cuenta; un repositorio Git local no acredita que ya exista publicación en GitHub. La guía de entrega identifica ese paso de forma explícita.

## Sexto efecto: inversión temporal

invertirAudio(x) usa y(n,c) = x(N+1-n,c), mediante flip(x,1). Conserva canales, cantidad de muestras, amplitud y Fs; valida con validarAudio y devuelve double. Se ejecuta después de velocidad. invertirActivo es false por defecto; las configuraciones anteriores sin este campo se aceptan como desactivadas.
