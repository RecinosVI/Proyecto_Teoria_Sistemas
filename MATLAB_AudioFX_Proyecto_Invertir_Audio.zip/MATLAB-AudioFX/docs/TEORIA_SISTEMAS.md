# Relación con Teoría de Sistemas

## Convenciones de análisis

Las propiedades se estudian con parámetros fijos y secuencias de tiempo discreto. Una señal finita se extiende con ceros cuando es necesario. Las condiciones de borde de un archivo y la normalización de salida deben distinguirse del operador matemático de cada efecto. Al mover controles durante el procesamiento, también cambia el sistema definido por esos parámetros.

Un operador es lineal si respeta superposición; causal si su salida en un instante no depende de entradas posteriores; sin memoria si depende solo de la entrada del mismo instante; BIBO estable si entradas acotadas producen salidas acotadas; e invariante en el tiempo si un retardo de entrada produce el mismo retardo de salida.

## Ganancia

`T_A{x}[n] = A x[n]`.

Es lineal, causal, sin memoria e invariante en el tiempo para `A` fijo. Para `|x[n]| ≤ M`, `|y[n]| ≤ |A|M`; por ello es BIBO estable para cualquier `A` finito. Su respuesta al impulso es `h[n] = A δ[n]` y su respuesta frecuencial `H(e^{jω}) = A`. Con `A < 0` invierte la polaridad; con `A = 0` produce silencio.

## Eco simple

`T_{D,alpha}{x}[n] = x[n] + alpha x[n−D]`, con `D = round(delaySeg × Fs)`.

Es lineal, causal e invariante en el tiempo para parámetros fijos y `D ≥ 0`. Tiene memoria cuando `D > 0` y `alpha ≠ 0`; con `D = 0` equivale a una ganancia `1+alpha`. Es BIBO estable, puesto que `|y[n]| ≤ (1+|alpha|)M`.

Su respuesta al impulso es `h[n] = δ[n] + alpha δ[n−D]`, y la respuesta frecuencial `H(e^{jω}) = 1 + alpha e^{-jωD}`. La magnitud satisface `|H|² = 1 + alpha² + 2 alpha cos(ωD)`: aparecen máximos y mínimos periódicos, un efecto de peine. El retardo no supone una realimentación; este módulo agrega una sola repetición.

Para un bloque de `N` muestras se devuelven `N+D` muestras. Así se escucha y exporta la última repetición, sin cortarla al final del archivo. Con `alpha = 0` esa cola está presente como ceros por coherencia del tamaño del bloque.

## Distorsión suave

`T_G{x}[n] = tanh(G x[n])`, con `G > 0`.

Es no lineal: en general `tanh(G(a+b))` no equivale a la suma de dos transformaciones. Es causal, sin memoria e invariante en el tiempo para `G` fijo. Es BIBO estable; su salida siempre está acotada en magnitud por 1.

Para amplitudes pequeñas se aproxima a `Gx`. Al aumentar la amplitud aparece saturación suave y una senoide puede producir armónicos. Por ser no lineal no tiene una única respuesta en frecuencia LTI independiente de la entrada. La FFT del resultado sirve para estudiar el cambio de contenido espectral, sin interpretarlo como un cociente universal de transferencia.

## Filtros Butterworth

El módulo diseña una cascada de secciones de segundo orden (SOS). Cada sección, con coeficientes `b` y `a`, aplica la ecuación causal:

`a[0] y[n] = sum_k b[k] x[n−k] − sum_{k≥1} a[k] y[n−k]`.

Con coeficientes fijos y estado inicial cero, el filtro es lineal, causal e invariante en el tiempo sobre secuencias. Tiene memoria y es BIBO estable cuando sus polos están dentro del círculo unidad. El diseño Butterworth digital con cortes válidos satisface esa condición teórica. La forma SOS reduce los problemas de condicionamiento de los polinomios de órdenes altos; los extremos numéricos siguen requiriendo validación.

Su respuesta frecuencial es `H(e^{jω}) = B(e^{jω})/A(e^{jω})`. El pasa bajos conserva las frecuencias bajas; el pasa altos conserva las altas; el pasa banda conserva un intervalo. El corte Butterworth corresponde aproximadamente a −3 dB respecto del nivel de la banda pasante. En un diseño pasa banda el orden final es el doble del argumento de orden. Estas convenciones se recogen en [butter](https://www.mathworks.com/help/signal/ref/butter.html).

Se usa `filter`, por lo que existe fase y transitorio de arranque. No se utiliza `filtfilt`, que procesa también en sentido inverso. La observación de una FFT global incluye el transitorio y los bordes; las pruebas de atenuación descartan el inicio del bloque antes de medir tonos.

## Cambio de velocidad mediante remuestreo

Idealmente se interpreta como `y[n] ≈ x[factor × n]`, con interpolación donde el índice no es entero. La implementación aproxima la razón inversa con enteros `P/Q` y obtiene alrededor de `ceil(N P/Q)` muestras. Guarda y reproduce a la misma `Fs`, de modo que un factor mayor que 1 acorta la duración y eleva el tono.

Para un factor fijo, el operador de remuestreo FIR es lineal y tiene memoria: combina muestras vecinas. Es acotado para factores finitos y un filtro finito, pero no equivale a un sistema LTI ordinario entre dos secuencias de la misma rejilla temporal. Un desplazamiento de una muestra de entrada no da, en general, un desplazamiento de una muestra de salida; cambia la escala del tiempo. El factor 1 se implementa como identidad, que sí es LTI y sin memoria.

La función de MATLAB aplica un filtro antialiasing y compensa su retardo. Esa compensación en procesamiento de archivos puede usar muestras futuras con respecto al índice de salida equivalente. Por ello esta implementación offline **no se presenta como un efecto causal de tiempo real**. Una implementación de flujo continuo requeriría latencia y gestión explícita del estado. La documentación de [resample](https://www.mathworks.com/help/signal/ref/resample.html) describe el filtrado y la compensación.

## FFT y comparación espectral

Para cada canal:

`X[k] = sum_{n=0}^{N−1} x[n] exp(−j 2πkn/N)`.

El espectro de amplitud empieza con `abs(X)/N`. Se retienen los bins `k = 0, …, floor(N/2)` y se duplican las amplitudes interiores. DC no se duplica. Si `N` es par, Nyquist tampoco se duplica; si es impar, el último bin positivo sí se duplica. El eje es `f[k] = k Fs/N`.

La escala permite recuperar la amplitud de una senoide que coincide con un bin. Para tonos entre bins existe fuga espectral; la FFT sin ventana de este proyecto no debe interpretarse como una estimación perfecta de amplitud para cualquier frecuencia. Las señales original y procesada pueden tener distinta longitud y, por tanto, distinta separación entre bins. El convenio de amplitud unilateral se basa en [fft](https://www.mathworks.com/help/matlab/ref/fft.html).

La DFT es una transformación lineal del bloque, pero la magnitud posterior no es lineal. Además, la FFT necesita el bloque completo; no se clasifica aquí como un efecto causal de audio.

## Escala final para reproducción y exportación

`z = y / max(1, max(abs(y(:))))`.

Esta protección global evita clipping y conserva la relación de amplitudes entre canales. Es no lineal y depende del bloque completo, por lo que tiene memoria y no es causal como operador de streaming. No se debe atribuir al módulo de ganancia la no linealidad introducida por esta etapa posterior.

## Resumen de propiedades

| Operador, con parámetros fijos | Lineal | Causal | Memoria | BIBO estable | Invariante en el tiempo |
|---|---|---|---|---|---|
| Ganancia finita | Sí | Sí | No | Sí | Sí |
| Eco, `D>0`, `alpha≠0` | Sí | Sí | Sí | Sí | Sí |
| Distorsión `tanh` | No | Sí | No | Sí | Sí |
| Butterworth causal estable | Sí | Sí | Sí | Sí, con polos estables | Sí |
| Velocidad, factor distinto de 1 | Sí, factor fijo | No garantizada por compensación offline | Sí | Sí, filtro FIR finito | No, cambia rejilla/escala |
| Velocidad, factor 1 | Sí | Sí | No | Sí | Sí |
| Normalización global del bloque | No | No para streaming | Sí | Sí | Depende de cómo se delimite el bloque |
