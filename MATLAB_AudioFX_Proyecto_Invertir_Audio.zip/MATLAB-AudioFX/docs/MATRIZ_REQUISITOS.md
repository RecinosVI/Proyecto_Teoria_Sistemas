# Matriz de trazabilidad de la especificación

Fuente: `Especificacion_Tecnica_MATLAB_AudioFX.docx`, facilitada para este proyecto. Esta matriz relaciona sus secciones con los artefactos y la forma de comprobarlos. **La existencia de una prueba o una guía no acredita por sí sola su ejecución**; el informe de verificación de la entrega contiene el resultado observado.

La entrega incluye el proyecto `.prj`, la aplicación nativa `.mlapp`, los módulos `.m`, los tests y la documentación. En MATLAB R2026b aprobaron 44 pruebas, 27 comprobaciones de interfaz fuente, 29 de interfaz nativa y 17 de callbacks y reproducción técnica. Las gráficas, capturas y los WAV fueron producidos por MATLAB. La carga y la exportación se recorrieron con sus cuadros de diálogo reales. La publicación GitHub requiere conectar la cuenta. La audición humana y las cancelaciones de diálogos se distinguen de los resultados automáticos en el estado y el registro de revisión.

| Sección del documento | Requisito | Implementación / artefacto | Verificación |
|---|---|---|---|
| 1. Objetivo | Adquirir/cargar, transformar, analizar, escuchar y exportar audio | WAV mediante `cargarAudio`, `procesarCadena`, `calcularFFT`, aplicación y `exportarAudio` | Pruebas y recorrido técnico nativo aprobados; audición humana y cancelaciones identificadas por separado |
| 2. Alcance | Seleccionar WAV y comparar original/resultado | Interfaz de carga, cuatro vistas de tiempo/FFT, reproducción y exportación | Selección de `prueba.wav`, metadatos, vistas y nuevo WAV comprobados en la app real |
| 3. Entorno | MATLAB Desktop, `.m`, App Designer `.mlapp`, Git | Módulos MATLAB, `app/AudioFX.mlapp`, respaldo `resources/source/AudioFX.m`, `MATLAB-AudioFX.prj` y repositorio local | Artefactos nativos generados y ejecutados en R2026b; publicación GitHub pendiente de conexión |
| 4. Arquitectura | Carpetas y algoritmos independientes | `src/`, `effects/`, `analysis/`, `audio/`, `app/`, `tests/`, `docs/`, `resources/` | Inspección de archivos y pruebas sin interfaz |
| 5. Flujo técnico | Inicialización, lectura, caracterización, tiempo, cadena, FFT y salida | `src/main.m`, cargador, procesamiento y utilidades | Demostración generada por MATLAB y app nativa ejecutada |
| 6.1 | WAV, mono/estéreo, frecuencia válida y reproducción | `cargarAudio`, matrices `N×C`, `audioplayer` | `testIO` y carga multicanal aprobados; original y resultado reproducidos con avance de muestras y finalización; valoración humana sin registrar |
| 6.2 | Ganancia `A*x`, control de clipping | `aplicarGanancia`, `prepararSalida`, `exportarAudio` | Pruebas de ganancia y normalización global |
| 6.3 | Eco `x[n]+alpha*x[n−D]` | `aplicarEco`, cola de `D` muestras | Impulso, retardo redondeado, repetición al final y retardo cero |
| 6.4 | Distorsión no lineal controlable | `aplicarDistorsion`, `tanh(G*x)` | Modelo exacto, límites, finitud y contraejemplo de linealidad |
| 6.5 | Pasa bajos y pasa altos; pasa banda opcional | `aplicarFiltro`, Butterworth SOS causal | Atenuación de tonos, preservación de canales y causalidad |
| 6.6 | Cambio de velocidad y método explicado | `cambiarVelocidad`, remuestreo inverso, `Fs` constante | Duración, canales, identidad y cambio de tono; teoría documentada |
| 6.7 | Espectro original y procesado | `calcularFFT`, FFT unilateral por canal | DC, Nyquist par, último bin impar, amplitud y eje de frecuencias |
| 7 | Todos los controles de interfaz | `app/AudioFX.mlapp` con carga, reproducción, controles de efectos, Procesar, Restablecer, exportación y vistas | 48 componentes y nueve callbacks serializados; 29 comprobaciones nativas y 17 de callbacks/reproducción aprobadas; capturas de tiempo/FFT; apertura, guardado y revalidación en el editor real |
| 8 | Conservar `x`, `y`, `Fs` y parámetros; procesar desde original | Estado de aplicación y `procesarCadena` | Reprocesamiento determinista, carga estéreo/mono y restablecimiento aprobados |
| 9 | No operar sin audio; errores de archivo/parámetros; Nyquist; clipping; canales | Validadores de módulos, comprobaciones de interfaz, salida segura | `testValidation`, canales y errores controlados GUI aprobados; cancelaciones de diálogo identificadas por separado |
| 10 | Pruebas aisladas e integradas; gráficas y escucha | 44 pruebas de función, señal conocida, gráficas y registro de reproducción/revisión | 44 pruebas MATLAB aprobadas; reproducción técnica original/resultado aprobada; percepción auditiva humana sin registrar |
| 11 | Explicar entrada, salida, memoria, causalidad, linealidad, estabilidad e invariancia | `docs/TEORIA_SISTEMAS.md` | Revisión de ecuaciones y demostración con impulso, tonos y FFT |
| 12 | Git y GitHub, commits descriptivos, rama principal funcional e ignorar cachés | Repositorio Git local con historial, ramas `main`/`develop` y `.gitignore` | `main` contiene la entrega funcional final; publicación GitHub aún no realizada por falta de conexión |
| 13 | `.prj`, `.m`, `.mlapp`, WAV de prueba/resultado, gráficas, efectos, Git, docs y demo | Proyecto, aplicación y módulos nativos; `audio/prueba.wav`, `audio/resultado_demo.wav`, `audio/prueba_procesado.wav`, cuatro PNG y documentos | Artefactos existentes y verificados en MATLAB; informes JSON de ejecución y de reproducción; referencia independiente etiquetada |
| 14 | Uso completo sin editar código | Aplicación nativa con diálogos y controles; inicio mediante proyecto y `iniciarAudioFX` | Apertura del `.prj`, carga por diálogo, botón Procesar, cuatro gráficas, reproducción real y exportación por diálogo aprobadas; ejecución desde otra carpeta verificada |
| 15 | Evolucionar prototipo modular previo | Estructura compatible con la descrita; módulos y app completan el flujo | No se presupone acceso al repositorio previo, que no fue adjuntado |

## Criterios de aceptación comprobables

1. Un WAV válido carga y muestra metadatos coherentes, tiempo y FFT.
2. Los efectos producen los valores previstos en señales deterministas y conservan el número de canales.
3. La cadena aplica su orden definido y cada nueva ejecución parte de `x`.
4. Ningún parámetro inválido puede producir silenciosamente NaN, Inf o índices negativos.
5. El pico se protege para escucha/exportación sin normalizar canales por separado.
6. Un WAV exportado vuelve a leerse con `Fs`, longitud y canales correctos.
7. La aplicación abre, responde a los controles, reproduce original/resultado y exporta sin editar código.
8. La documentación explica las propiedades de cada operador con las excepciones de remuestreo y normalización global.
9. La revisión final indica cualquier comprobación pendiente y el estado real de la publicación GitHub.
