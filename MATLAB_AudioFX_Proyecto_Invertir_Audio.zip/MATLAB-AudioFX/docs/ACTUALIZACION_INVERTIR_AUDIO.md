# Actualización: Invertir audio

Fecha de entrega: 15 de octubre de 2026.

## Implementación

El sexto efecto invierte el orden temporal: y(n,c) = x(N+1-n,c). Mono y estéreo conservan sus canales; una fila es una muestra multicanal, no un vector temporal. Se conservan amplitud, cantidad de muestras y Fs. El contrato devuelve double, igual que los demás efectos.

Orden: ganancia → eco → distorsión → filtro → velocidad → invertir. La inversión incluye la cola del eco y el resultado del remuestreo. La cadena sigue procesando el original en cada ejecución.

Archivos principales: `effects/invertirAudio.m`, parámetros y cadena en `src/`, fuente de interfaz en `resources/source/AudioFX.m`, aplicación nativa regenerada en `app/AudioFX.mlapp`. La casilla usa el callback existente para detener reproducción, invalidar el resultado y limpiar gráficas; Restablecer la desactiva. `buildAppDesigner.m` conserva el enlace al regenerar.

La opción `invertirActivo` es false por defecto. Las estructuras de parámetros anteriores sin ese campo siguen funcionando; los indicadores inválidos se rechazan.

## Verificación realizada

- MATLAB R2026b, licencia de evaluación disponible en este equipo: 52 pruebas aprobadas, cero fallidas/incompletas. Incluye ocho nuevas para el efecto, validación y cadena combinada.
- App nativa: regeneración mediante el serializador MATLAB; código recargado y callbacks validados, 49 componentes y nueve callbacks.
- 33 comprobaciones programáticas de interfaz: carga, gráficas, inversión exacta, callback de casilla, invalidación, reprocesamiento desde original, combinación de efectos, exportación PCM24 y restablecimiento.
- Proyecto nativo regenerado correctamente. MATLAB avisó que no pudo iniciar el control Git por la propiedad del repositorio incluido y advirtió sobre rutas ya agregadas; no impidió las pruebas ni la generación. No se alteró la configuración global de confianza Git.
- 12 comprobaciones estáticas ejecutadas con PowerShell sin MATLAB. Revisan contrato y conexiones de código, presencia de las ocho pruebas, descriptor de proyecto y contenido de código/modelo del MLAPP. No sustituyen la ejecución numérica MATLAB.

Evidencia actual: `verificacion_invertir_audio.json`, `verificacion_sin_matlab_invertir.json` y registros `ejecucion_invertir_audio.log` / `ejecucion_interfaz_invertir.log`.

## Repetir

Desde la raíz en MATLAB:

```matlab
addpath('tests','src');
results = run_tests;
informe = verificarApp;
```

Para regenerar artefactos nativos:

```matlab
addpath('src');
buildAppDesigner(pwd);
buildProject(pwd);
```

Desde PowerShell, sin MATLAB:

```powershell
./tests/verificarSinMatlab.ps1
```

## Pendientes de revisión manual

1. Escuchar original y resultado mono/estéreo en el dispositivo de salida y evaluar la inversión.
2. Revisar visualmente la casilla y el ajuste de los controles a diferentes tamaños de ventana.
3. Abrir la app en App Designer, guardar y volver a ejecutar; el ciclo nativo de serialización sí se comprobó, el guardado manual en el editor no.
4. Repetir carga y exportación con los cuadros de diálogo reales. La carga/exportación programática y la cuantización WAV sí se verificaron.

Los informes, capturas, audios y documentación previos conservados pertenecen a la entrega original. Las afirmaciones históricas de revisión visual y reproducción no se extienden al sexto efecto. No se requiere la especificación técnica externa para utilizar esta actualización; no se ha realizado una auditoría nueva de requisitos ajenos a esta solicitud.
