# Demostración final y revisión de audio

## Propósito y registro

Este protocolo permite presentar el flujo completo y revisar la interacción y la percepción auditiva. La entrega ya incluye la ejecución correcta de 44 pruebas MATLAB, 27 comprobaciones de interfaz fuente, 29 de interfaz nativa y 17 de callbacks y reproducción. `resources/registro_revision_manual.csv` contiene los resultados técnicos observados y señala por separado los casos de interacción o valoración humana sin registrar. No se marca una evaluación perceptiva como aprobada a partir de datos numéricos.

La demostración MATLAB produjo `audio/resultado_demo.wav`, `docs/comparacion_tiempo.png` y `docs/comparacion_fft.png`. La app nativa produjo las capturas `docs/interfaz_tiempo.png` y `docs/interfaz_fft.png`. Se reprodujeron íntegramente el original de 3 s y el resultado de 2.6 s mediante el dispositivo de salida de Windows; el informe registra avance de muestras y finalización. `audicionHumanaObservada` es `false`.

La revisión del editor mostró la app en la vista Diseño de App Designer y su árbol de componentes sin errores de apertura. Se efectuó el guardado con Ctrl+S y desapareció la marca de cambios pendientes del título.

## Preparación

1. Abrir el proyecto nativo y la aplicación siguiendo el manual; sus archivos ya están incluidos. Para regenerarlos, ejecutar `generarEntregables` en una sesión licenciada.
2. Anotar versión de MATLAB y toolboxes si se repite la revisión. Ejecutar `addpath('tests'); results = run_tests;` para repetir las pruebas y conservar el nuevo resultado real.
3. Revisar el volumen del equipo. Tener disponibles `audio/prueba.wav`, el resultado entregado y un WAV propio si se desea ampliar la demostración.
4. Elegir una carpeta de salida y un nombre que no coincida con un WAV que deba conservarse.

Como comprobación programática adicional, `addpath('src'); informeGUI = verificarApp;` revisa botones, gráficos, carga estéreo/mono, parámetros, reprocesamiento y exportación de la clase `AudioFX` disponible en el Path. En el paquete final se ejecuta la app nativa. Esta función no reproduce audio; esa evidencia está en `docs/verificacion_callbacks_audio.json`. La carga de `audio/prueba.wav` y la exportación de `audio/prueba_procesado.wav` se completaron también con los cuadros de diálogo reales. Las cancelaciones permanecen como casos separados del protocolo.

## Recorrido recomendado de presentación

| Paso | Acción | Qué comprobar o explicar |
|---:|---|---|
| 1 | Cargar `audio/prueba.wav` | Nombre, `Fs`, muestras, duración y canales; relación entre archivo y `x[n]`. |
| 2 | Escuchar el original | El dispositivo reproduce audio; registrar la revisión auditiva real. |
| 3 | Procesar con valores iniciales | Identidad matemática; gráficas original/resultado coherentes. |
| 4 | Ganancia 0.5 | Misma duración y amplitud reducida; explicar operador lineal sin memoria. |
| 5 | Activar eco, 0.25 s y `alpha=0.35` | Repetición retardada, cola final y longitud incrementada; explicar memoria y causalidad. |
| 6 | Desactivar eco, activar distorsión, `G=4` | Saturación suave, cambios de forma y armónicos en FFT; explicar no linealidad. |
| 7 | Comparar pasa bajos y pasa altos | Reducción de las componentes que quedan fuera de la banda; validar cortes respecto de Nyquist. |
| 8 | Probar pasa banda | Dos cortes crecientes y conservación de las frecuencias intermedias. |
| 9 | Desactivar efectos opcionales, velocidad 2 y 0.5 | Duración y tono cambian; `Fs` de salida se conserva. |
| 10 | Activar una cadena de varios efectos | Explicar su orden y comparar tiempo/FFT; pulsar Procesar dos veces para verificar ausencia de acumulación. |
| 11 | Escuchar el resultado | Comprobar ausencia de saltos inesperados, cortes de eco y saturación por salida. La distorsión activada debe seguir siendo perceptible. |
| 12 | Exportar con nombre nuevo | Abrir el WAV exportado y comprobar `audioinfo`/`audioread`; confirmar duración, canales y protección de pico. |
| 13 | Restablecer parámetros y cargar otro WAV | El estado y los controles se actualizan de forma coherente. |

La señal sintética permite resultados reproducibles, pero no equivale a grabaciones de voz o música. Para una revisión perceptiva adicional usar material propio y registrar sus datos. No hace falta generar ni adjuntar una grabación de voz del usuario.

## Casos de error que deben revisarse en la interfaz

| Caso | Resultado esperado |
|---|---|
| Pulsar Procesar sin cargar audio | Mensaje comprensible y estado coherente. |
| Intentar escuchar o exportar sin señal | Operación impedida con mensaje. |
| Cancelar la selección de WAV | No sustituye una señal existente ni lanza un error. |
| Seleccionar un archivo inválido o ilegible | Mensaje de lectura; no deja muestras inválidas. |
| Corte igual a cero, a Nyquist o superior | Rechazo antes de filtrar. |
| Pasa banda con cortes invertidos | Rechazo; pedir banda creciente. |
| Pico mayor que 1 por ganancia o eco | Aviso/metadatos de escala y salida protegida para escucha/exportación. |
| Cargar mono después de estéreo | Número de canales y vistas coherentes con el nuevo WAV. |
| Exportación cancelada o a destino no escribible | Cancelación segura o mensaje de escritura. |

## Qué cuenta como evidencia

- Resultado de `run_tests` con todas las pruebas aprobadas y entorno identificado.
- Capturas o imágenes de las gráficas con ejes, unidades y parámetros reconocibles.
- WAV exportado que vuelve a abrirse y cuya amplitud queda en el intervalo válido.
- Registro de reproducción técnica real en el equipo, con avance de muestras y finalización; para una revisión perceptiva, añadir observaciones de una persona que haya escuchado los audios.
- Historial Git local verificable. Para afirmar publicación en GitHub, añadir la URL del repositorio remoto y verificar que contiene la versión entregada.

Un informe estático no acredita que se hayan escuchado los audios. Una captura de código tampoco acredita que App Designer haya abierto o ejecutado la aplicación. Mantener estas verificaciones identificadas permite cerrar la entrega sin inventar evidencia.

## Publicación del repositorio cuando exista cuenta y remoto

1. Crear en GitHub un repositorio vacío dentro de la cuenta o la organización autorizada.
2. Desde la raíz del proyecto, inspeccionar `git status` y `git log --oneline`.
3. Registrar el remoto con `git remote add origin URL_DEL_REPOSITORIO` solo si todavía no existe; si existe, comprobarlo con `git remote -v`.
4. Verificar la rama actual con `git branch --show-current` y subir esa rama con `git push -u origin NOMBRE_DE_RAMA`.
5. Confirmar en GitHub que están el proyecto, el código, los audios de prueba y la documentación, y anotar la URL en el registro de entrega.

Estos comandos son una guía de publicación. No indican que se haya enviado código a una cuenta externa durante la preparación de los archivos.
