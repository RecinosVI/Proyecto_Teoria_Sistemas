# Manual de uso de MATLAB AudioFX

## Requisitos y apertura

La plataforma objetivo de la especificación es MATLAB R2026b. Los módulos de filtros y cambio de velocidad necesitan **Signal Processing Toolbox** (`butter`, `resample`). La carga, las gráficas, la FFT, `audioplayer` y la exportación utilizan funciones de MATLAB. Audio Toolbox y DSP System Toolbox forman parte del entorno previsto por el documento, pero los algoritmos entregados no dependen de ellos.

**Estado de esta entrega:** el proyecto `MATLAB-AudioFX.prj` y la app `app/AudioFX.mlapp` están generados y verificados en MATLAB R2026b. Pasaron 44 pruebas MATLAB, 27 comprobaciones de la interfaz fuente, 29 de la app nativa y 17 de callbacks y reproducción técnica. La entrega incluye el WAV procesado y cuatro imágenes de gráficas e interfaz. Original y resultado se reprodujeron en el dispositivo real con avance de muestras y finalización observados; no se registra una valoración auditiva humana.

El archivo nativo se abrió en el editor real de App Designer, donde se mostraron la vista Diseño y el árbol de componentes. Se guardó desde el editor con Ctrl+S.

1. Extraer el paquete completo conservando sus carpetas.
2. Abrir `MATLAB-AudioFX.prj` en MATLAB. El proyecto configura las rutas; ejecutar su acceso directo **Iniciar AudioFX** o escribir `iniciarAudioFX` desde la raíz para iniciar la aplicación nativa.
3. Para editar la interfaz, abrir `app/AudioFX.mlapp` en App Designer; se ejecuta con **Run** cuando el proyecto está abierto. Los artefactos ya están incluidos y no es necesario generarlos para usar la app. `generarEntregables` permite regenerarlos y repetir la verificación.
4. `src/main.m` es otro punto de entrada. `generarDemostracion` ejecuta la cadena y produce WAV y gráficas desde MATLAB sin utilizar la interfaz.
5. Mantener las funciones y los audios dentro del árbol del proyecto. No es necesario editar algoritmos para cargar otro WAV desde la interfaz.

## Flujo completo en la aplicación

1. Pulsar **Cargar WAV**. Seleccionar `audio/prueba.wav` o un WAV propio. La aplicación conserva el original como `x`, su frecuencia `Fs` y sus canales. La duración se calcula como `N/Fs`.
2. Examinar la señal original en el tiempo y su espectro. Cada columna de la matriz de audio corresponde a un canal; se procesa por separado.
3. Reproducir el original. Empezar con un volumen cómodo en los altavoces o auriculares del equipo.
4. Configurar los parámetros. Activar los efectos que se deseen y pulsar **Procesar**. La cadena comienza otra vez desde el original en cada ejecución.
5. Comparar las gráficas original/procesada y las FFT. Una duración distinta después de eco o velocidad es esperable; cada gráfica utiliza su propio eje temporal.
6. Reproducir el resultado. Cuando el pico excede la unidad, la versión enviada al dispositivo se escala globalmente para evitar saturación. Las gráficas conservan la señal matemática procesada.
7. Pulsar **Exportar WAV** y seleccionar un nombre nuevo. La exportación usa PCM de 24 bits y una sola escala para todos los canales si el pico supera 1. El WAV podrá diferir de la señal de las gráficas por esa escala y por la cuantización.
8. Pulsar **Restablecer** para volver a los valores iniciales; volver a pulsar **Procesar** cuando corresponda.

Si no hay una señal cargada, no se puede procesar, reproducir ni exportar. Al cancelar un diálogo no se sustituye el audio por datos vacíos. Los errores de lectura o parámetros se comunican desde la interfaz.

## Parámetros y significado

| Parámetro | Valor inicial | Interpretación |
|---|---:|---|
| Ganancia `A` | 1 | Multiplica todas las muestras por `A`. 0.5 reduce amplitud a la mitad; 2 la duplica. |
| Eco activado | No | Añade una repetición. |
| Retardo | 0.25 s | `D = round(retardo × Fs)` muestras. La cola final se conserva. |
| Intensidad del eco `alpha` | 0.35 | Peso de la copia retardada; rango de 0 a 1. |
| Distorsión activada | No | Aplica `tanh(G × x)`; no es una ganancia lineal. |
| Intensidad `G` | 2 | Debe ser mayor que cero. Un valor mayor aumenta la saturación suave. |
| Filtro activado | No | Filtrado Butterworth con estado inicial cero. |
| Tipo | Pasa bajos | También se incluyen pasa altos y pasa banda. |
| Corte | 1000 Hz | Debe estar estrictamente entre 0 y `Fs/2`; en pasa banda se requieren dos cortes crecientes. |
| Orden | 4 | Entero positivo; en pasa banda Butterworth el orden final es `2 × orden`. |
| Velocidad | 1 | 2 acelera y reduce aproximadamente a la mitad la duración; 0.5 ralentiza y duplica la duración. |

Los módulos aceptan los parámetros de su contrato matemático. Los controles de la interfaz limitan ganancia a 0–20, retardo a 0–5 segundos, intensidad de distorsión a 0.1–30, orden a 1–10 y velocidad a 0.25–4 por comodidad y coste de memoria. Antes de utilizar un corte de 1000 Hz con un WAV de frecuencia muy baja, elegir un corte menor que su frecuencia de Nyquist.

El cambio de velocidad remuestrea con un cociente racional aproximado a `1/factor`; **la frecuencia de muestreo guardada y reproducida se conserva**. Por tanto, cambia también el tono. No es un algoritmo de estiramiento temporal que conserve la altura musical.

## Uso por código

Desde la raíz del proyecto:

```matlab
addpath('src','effects','analysis');
[x, Fs, entrada] = cargarAudio(fullfile('audio','prueba.wav'));
p = parametrosPorDefecto();
p.ganancia = 0.8;
p.ecoActivo = true;
p.delaySeg = 0.2;
p.alpha = 0.35;
p.distorsionActiva = true;
p.intensidad = 2;
p.filtroActivo = true;
p.tipoFiltro = 'pasabajos';
p.fc = 3000;
p.velocidad = 1.1;
[y, FsSalida, procesamiento] = procesarCadena(x, Fs, p);
[fOriginal, magOriginal] = calcularFFT(x, Fs);
[fSalida, magSalida] = calcularFFT(y, FsSalida);
[yEscucha, factor, pico] = prepararSalida(y);
reproductor = audioplayer(yEscucha, FsSalida);
play(reproductor);
exportacion = exportarAudio(y, FsSalida, 'resultado_personal.wav');
```

Elegir un nombre de exportación nuevo para conservar cualquier WAV anterior. `procesarCadena` no modifica `x` ni normaliza automáticamente `y`; `prepararSalida` y `exportarAudio` se ocupan de la escala para escucha y salida.

## Pruebas y resolución de problemas

```matlab
addpath('tests');
results = run_tests;
```

El ejecutor exige que todas las pruebas pasen mediante `assertSuccess`. Las 44 pruebas de esta entrega se ejecutaron y aprobaron en MATLAB R2026b. Si al repetirlas aparece un fallo, revisar el resultado y el entorno. `docs/verificacion_matlab.json` contiene la evidencia de la ejecución final.

Para comprobar además la conexión entre los controles y los módulos sin reproducir audio:

```matlab
addpath('src');
informeGUI = verificarApp;
```

Esta verificación instancia la clase `AudioFX` disponible en el MATLAB Path; en el paquete final corresponde a `app/AudioFX.mlapp`. Se registraron 27 comprobaciones correctas con la fuente y 29 con la app nativa. La verificación de reproducción y callbacks se registra por separado en `docs/verificacion_callbacks_audio.json`. Los diálogos reales de carga y exportación fueron recorridos; sus cancelaciones y una valoración auditiva humana se distinguen en el registro de revisión.

| Situación | Acción |
|---|---|
| `butter` o `resample` no disponibles | Comprobar la instalación y licencia de Signal Processing Toolbox. |
| WAV ilegible | Comprobar que el archivo exista y pueda abrirse con `audioread`. |
| Corte rechazado | Usar `0 < corte < Fs/2`; para banda, `0 < inferior < superior < Fs/2`. |
| Resultado más largo | Revisar el retardo del eco y los factores de velocidad menores que 1. |
| Nivel exportado menor que la gráfica | Revisar el pico y el factor de normalización global informado. |
| Cambio de tono al variar velocidad | Es el comportamiento previsto del remuestreo usado. |
| Reproducción sin sonido | Verificar dispositivo, volumen y que el audio no sea silencio; la reproducción depende del equipo. |

## Referencias de las funciones del proveedor

La elección del remuestreo y su compensación de retardo se basa en la documentación oficial de [resample](https://www.mathworks.com/help/signal/ref/resample.html). El diseño normalizado y los tipos disponibles están descritos en [butter](https://www.mathworks.com/help/signal/ref/butter.html). La transformación y el escalado del espectro se explican en [fft](https://www.mathworks.com/help/matlab/ref/fft.html).

## Invertir audio (sexto efecto)

Marque **Invertir audio** y pulse **Procesar**. El resultado recorre las muestras desde el final al principio, por separado en cada canal. No cambia la polaridad ni intercambia izquierda y derecha. Se aplica después de ganancia, eco, distorsión, filtro y velocidad. La inversión por sí sola conserva amplitud, duración y frecuencia de muestreo. **Escuchar resultado**, las gráficas y **Exportar WAV** usan ese mismo resultado.

Al cambiar la casilla se detiene la reproducción y se invalida el resultado anterior. **Restablecer parámetros** desmarca la casilla. Cada procesamiento parte del original; pulsar Procesar dos veces no deshace la inversión.

Desde código: `p = parametrosPorDefecto(); p.invertirActivo = true; [y,FsOut,info] = procesarCadena(x,Fs,p);`.
