function results = run_tests
%RUN_TESTS Ejecuta todas las pruebas automatizadas y exige éxito total.
% Desde la raíz: addpath('tests'); results = run_tests;
root = fileparts(fileparts(mfilename('fullpath')));
oldPath = path; cleanup = onCleanup(@() path(oldPath)); %#ok<NASGU>
addpath(fullfile(root,'src'),fullfile(root,'effects'),fullfile(root,'analysis'));
suite = testsuite(fullfile(root,'tests'),'IncludeSubfolders',true);
results = run(suite);
assertSuccess(results);
end
