function tests = testEffects
%TESTEFFECTS Pruebas matemáticas deterministas de los módulos independientes.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
root = fileparts(fileparts(mfilename('fullpath')));
testCase.TestData.oldPath = path;
addpath(fullfile(root,'src'),fullfile(root,'effects'),fullfile(root,'analysis'));
end

function teardownOnce(testCase)
path(testCase.TestData.oldPath);
end

function testGananciaEscalaTodosLosCanales(testCase)
x = [0.4 -0.2 0.1; -0.8 0.6 -0.3; 0 0 0];
y = aplicarGanancia(x,0.5);
verifyEqual(testCase,y,0.5*x,'AbsTol',1e-14);
verifySize(testCase,y,size(x));
end

function testGananciaIdentidadYSilencio(testCase)
x = [-0.7; 0; 0.2];
verifyEqual(testCase,aplicarGanancia(x,1),x);
verifyEqual(testCase,aplicarGanancia(x,0),zeros(size(x)));
verifyEqual(testCase,aplicarGanancia(x,-1),-x);
end

function testEcoImpulsoRetardoYCola(testCase)
Fs = 8000; D = 80;
x = zeros(200,2); x(1,:) = [1 0.4];
y = aplicarEco(x,Fs,D/Fs,0.25);
expected = zeros(280,2);
expected(1,:) = [1 0.4]; expected(D+1,:) = [0.25 0.1];
verifyEqual(testCase,y,expected,'AbsTol',1e-14);
end

function testEcoConservaRepeticionAlFinal(testCase)
Fs = 1000; x = [zeros(9,1); 0.8];
y = aplicarEco(x,Fs,0.004,0.5);
verifySize(testCase,y,[14 1]);
verifyEqual(testCase,y(10),0.8,'AbsTol',1e-14);
verifyEqual(testCase,y(14),0.4,'AbsTol',1e-14);
end

function testEcoRetardoCero(testCase)
x = [-0.3 0.5; 0.7 -0.2];
verifyEqual(testCase,aplicarEco(x,8000,0,0.5),1.5*x,'AbsTol',1e-14);
end

function testEcoRedondeaRetardo(testCase)
x = [1; zeros(4,1)];
y = aplicarEco(x,1000,0.0016,0.5);
verifySize(testCase,y,[7 1]);
verifyEqual(testCase,y(3),0.5,'AbsTol',1e-14);
end

function testEcoUnaMuestraMulticanal(testCase)
x = [0.2 -0.4 0.6];
y = aplicarEco(x,1000,0.002,0.5);
verifyEqual(testCase,y,[x; zeros(1,3); 0.5*x],'AbsTol',1e-14);
end

function testDistorsionModeloYLimites(testCase)
x = [-100 -0.8; 0 0; 100 0.8];
y = aplicarDistorsion(x,3);
verifyEqual(testCase,y,tanh(3*x),'AbsTol',1e-14);
verifyLessThanOrEqual(testCase,max(abs(y(:))),1);
verifyTrue(testCase,all(isfinite(y(:))));
end

function testDistorsionNoEsLineal(testCase)
x = [0.2; 0.6];
difference = aplicarDistorsion(2*x,2)-2*aplicarDistorsion(x,2);
verifyGreaterThan(testCase,norm(difference),0.1);
end

function testPasaBajosAtenuaFrecuenciaAlta(testCase)
Fs = 8000; t = (0:2*Fs-1)'/Fs;
x = sin(2*pi*250*t)+sin(2*pi*2000*t);
y = aplicarFiltro(x,Fs,'pasabajos',1000,4);
verifySize(testCase,y,size(x));
verifyGreaterThan(testCase,amplitudTono(y,Fs,250,Fs/2),0.9);
verifyLessThan(testCase,amplitudTono(y,Fs,2000,Fs/2),0.1);
end

function testPasaAltosAtenuaFrecuenciaBaja(testCase)
Fs = 8000; t = (0:2*Fs-1)'/Fs;
x = sin(2*pi*250*t)+sin(2*pi*2000*t);
y = aplicarFiltro(x,Fs,'pasaaltos',1000,4);
verifyLessThan(testCase,amplitudTono(y,Fs,250,Fs/2),0.1);
verifyGreaterThan(testCase,amplitudTono(y,Fs,2000,Fs/2),0.9);
end

function testPasaBandaSeleccionaTonoCentral(testCase)
Fs = 8000; t = (0:2*Fs-1)'/Fs;
x = sin(2*pi*250*t)+sin(2*pi*1000*t)+sin(2*pi*2500*t);
y = aplicarFiltro(x,Fs,'pasabanda',[800 1200],4);
verifyGreaterThan(testCase,amplitudTono(y,Fs,1000,Fs/2),0.9);
verifyLessThan(testCase,amplitudTono(y,Fs,250,Fs/2),0.1);
verifyLessThan(testCase,amplitudTono(y,Fs,2500,Fs/2),0.1);
end

function testFiltroCanalesIndependientesYCausal(testCase)
x = zeros(256,3); x(100,:) = [1 0.5 -0.25];
y = aplicarFiltro(x,8000,'pasabajos',1000);
verifySize(testCase,y,size(x));
verifyEqual(testCase,y(1:99,:),zeros(99,3),'AbsTol',1e-14);
verifyEqual(testCase,y(:,2),0.5*y(:,1),'AbsTol',1e-12);
verifyEqual(testCase,y(:,3),-0.25*y(:,1),'AbsTol',1e-12);
verifyTrue(testCase,all(isfinite(y(:))));
end

function testVelocidadIdentidad(testCase)
x = [linspace(-0.5,0.5,200)' zeros(200,1)];
[y,FsOut] = cambiarVelocidad(x,8000,1);
verifyEqual(testCase,y,x);
verifyEqual(testCase,FsOut,8000);
end

function testVelocidadCambiaDuracionYConservaCanales(testCase)
x = zeros(8000,3); x(4000,:) = [0.3 0.2 0.1];
[fast,FsFast] = cambiarVelocidad(x,8000,2);
[slow,FsSlow] = cambiarVelocidad(x,8000,0.5);
verifySize(testCase,fast,[4000 3]);
verifySize(testCase,slow,[16000 3]);
verifyEqual(testCase,[FsFast FsSlow],[8000 8000]);
verifyTrue(testCase,all(isfinite(fast(:))) && all(isfinite(slow(:))));
end

function testVelocidadCambiaTono(testCase)
Fs = 8000; t = (0:Fs-1)'/Fs;
x = 0.3*sin(2*pi*400*t);
[y,FsOut] = cambiarVelocidad(x,Fs,2);
[f,magnitude] = calcularFFT(y,FsOut);
[~,peak] = max(magnitude(:,1));
verifyEqual(testCase,f(peak),800,'AbsTol',2);
end

function testVelocidadUnaMuestraMulticanal(testCase)
x = [0.2 0.4 -0.1];
[y,FsOut] = cambiarVelocidad(x,8000,0.5);
verifySize(testCase,y,[2 3]);
verifyEqual(testCase,y(:,2),2*y(:,1),'AbsTol',1e-12);
verifyEqual(testCase,y(:,3),-0.5*y(:,1),'AbsTol',1e-12);
verifyEqual(testCase,FsOut,8000);
end

function amplitude = amplitudTono(x,Fs,frequency,discard)
% Proyección compleja tras descartar el transitorio de arranque del IIR.
n = (discard:size(x,1)-1)';
segment = x(discard+1:end,1);
amplitude = 2*abs(sum(segment.*exp(-1i*2*pi*frequency*n/Fs)))/numel(segment);
end
