function tests = testValidation
%TESTVALIDATION Entradas inválidas deben producir errores controlados.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
root = fileparts(fileparts(mfilename('fullpath')));
testCase.TestData.oldPath = path;
addpath(fullfile(root,'src'),fullfile(root,'effects'),fullfile(root,'analysis'));
end

function teardownOnce(testCase)
path(testCase.TestData.oldPath);
end

function testRechazaAudioVacioNoFinitoYComplejo(testCase)
verifyError(testCase,@() aplicarGanancia([],1),'AudioFX:AudioInvalido');
verifyError(testCase,@() aplicarGanancia([0; NaN],1),'AudioFX:AudioNoFinito');
verifyError(testCase,@() aplicarDistorsion([0; Inf],2),'AudioFX:AudioNoFinito');
verifyError(testCase,@() calcularFFT([1; 1i],8000),'AudioFX:AudioInvalido');
end

function testRechazaGananciaNoFinita(testCase)
verifyError(testCase,@() aplicarGanancia([0.1; 0.2],Inf),'AudioFX:GananciaInvalida');
verifyError(testCase,@() aplicarGanancia([0.1; 0.2],[1 2]),'AudioFX:GananciaInvalida');
end

function testRechazaRetardoYFsInvalidos(testCase)
x = [0.1; 0.2];
verifyError(testCase,@() aplicarEco(x,8000,-0.1,0.4),'AudioFX:RetardoInvalido');
verifyError(testCase,@() aplicarEco(x,0,0.1,0.4),'AudioFX:FrecuenciaMuestreoInvalida');
verifyError(testCase,@() aplicarEco(x,8000,NaN,0.4),'AudioFX:RetardoInvalido');
end

function testRechazaIntensidadesInvalidas(testCase)
x = [0.1; 0.2];
verifyError(testCase,@() aplicarEco(x,8000,0.1,-0.1),'AudioFX:IntensidadEcoInvalida');
verifyError(testCase,@() aplicarEco(x,8000,0.1,1.1),'AudioFX:IntensidadEcoInvalida');
verifyError(testCase,@() aplicarDistorsion(x,0),'AudioFX:DistorsionInvalida');
verifyError(testCase,@() aplicarDistorsion(x,NaN),'AudioFX:DistorsionInvalida');
end

function testRechazaFrecuenciaFueraDeNyquist(testCase)
x = zeros(100,1);
verifyError(testCase,@() aplicarFiltro(x,8000,'pasabajos',0),'AudioFX:FrecuenciaCorteInvalida');
verifyError(testCase,@() aplicarFiltro(x,8000,'pasaaltos',4000),'AudioFX:FrecuenciaCorteInvalida');
verifyError(testCase,@() aplicarFiltro(x,8000,'pasabanda',[2000 1000]),'AudioFX:FrecuenciaCorteInvalida');
verifyError(testCase,@() aplicarFiltro(x,8000,'desconocido',1000),'AudioFX:TipoFiltroInvalido');
verifyError(testCase,@() aplicarFiltro(x,8000,'pasabajos',1000,0),'AudioFX:OrdenFiltroInvalido');
verifyError(testCase,@() aplicarFiltro(x,8000,'pasabajos',1000,1.5),'AudioFX:OrdenFiltroInvalido');
end

function testRechazaVelocidadYFsInvalidos(testCase)
x = zeros(100,1);
verifyError(testCase,@() cambiarVelocidad(x,8000,0),'AudioFX:VelocidadInvalida');
verifyError(testCase,@() cambiarVelocidad(x,8000,-1),'AudioFX:VelocidadInvalida');
verifyError(testCase,@() cambiarVelocidad(x,8000,Inf),'AudioFX:VelocidadInvalida');
verifyError(testCase,@() calcularFFT(x,0),'AudioFX:FrecuenciaMuestreoInvalida');
end

function testRechazaArchivoInexistenteYExportacionInvalida(testCase)
verifyThrows(testCase,@() cargarAudio([tempname '.wav']));
verifyThrows(testCase,@() exportarAudio([0; NaN],8000,[tempname '.wav']));
verifyThrows(testCase,@() exportarAudio(zeros(100,1),0,[tempname '.wav']));
end

function verifyThrows(testCase,callback)
% Los identificadores exactos pueden evolucionar; exigimos una excepción.
caught = [];
try
    callback();
catch exception
    caught = exception;
end
verifyFalse(testCase,isempty(caught),'La operación inválida no produjo error.');
if ~isempty(caught)
    verifyNotEmpty(testCase,caught.message,'El error debe ser comprensible.');
end
end
