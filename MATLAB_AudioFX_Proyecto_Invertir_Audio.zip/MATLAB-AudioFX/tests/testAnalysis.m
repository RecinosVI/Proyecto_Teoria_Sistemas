function tests = testAnalysis
%TESTANALYSIS Convención de amplitud unilateral, eje y canales de la FFT.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
root = fileparts(fileparts(mfilename('fullpath')));
testCase.TestData.oldPath = path;
addpath(fullfile(root,'src'),fullfile(root,'effects'),fullfile(root,'analysis'));
end

function teardownOnce(testCase)
path(testCase.TestData.oldPath);
end

function testTonoParAmplitudYFrecuencia(testCase)
N = 1000; Fs = 1000; n = (0:N-1)';
x = 0.6*cos(2*pi*40*n/N);
[f,magnitude] = calcularFFT(x,Fs);
verifySize(testCase,f,[501 1]);
verifySize(testCase,magnitude,[501 1]);
verifyEqual(testCase,f(41),40,'AbsTol',1e-12);
verifyEqual(testCase,magnitude(41),0.6,'AbsTol',1e-12);
end

function testDCNoSeDuplica(testCase)
[f,magnitude] = calcularFFT(0.3*ones(64,1),8000);
verifyEqual(testCase,f(1),0);
verifyEqual(testCase,magnitude(1),0.3,'AbsTol',1e-12);
verifyEqual(testCase,magnitude(2:end),zeros(32,1),'AbsTol',1e-12);
end

function testNyquistParNoSeDuplica(testCase)
N = 64; x = 0.4*(-1).^(0:N-1)';
[f,magnitude] = calcularFFT(x,8000);
verifyEqual(testCase,f(end),4000);
verifyEqual(testCase,magnitude(end),0.4,'AbsTol',1e-12);
end

function testUltimoBinImparSiSeDuplica(testCase)
N = 999; k = floor(N/2); n = (0:N-1)';
x = 0.7*cos(2*pi*k*n/N);
[f,magnitude] = calcularFFT(x,999);
verifySize(testCase,magnitude,[500 1]);
verifyEqual(testCase,f(end),499,'AbsTol',1e-12);
verifyEqual(testCase,magnitude(end),0.7,'AbsTol',1e-11);
end

function testFFTNoMezclaCanales(testCase)
N = 1000; n = (0:N-1)';
x = [0.4*cos(2*pi*50*n/N) 0.2*cos(2*pi*120*n/N) zeros(N,1)];
[~,magnitude] = calcularFFT(x,1000);
verifySize(testCase,magnitude,[501 3]);
verifyEqual(testCase,magnitude(51,1),0.4,'AbsTol',1e-12);
verifyEqual(testCase,magnitude(121,2),0.2,'AbsTol',1e-12);
verifyEqual(testCase,magnitude(:,3),zeros(501,1));
verifyLessThan(testCase,magnitude(51,2),1e-12);
end

function testFFTUnaMuestra(testCase)
[f,magnitude] = calcularFFT(0.7,8000);
verifyEqual(testCase,f,0);
verifyEqual(testCase,magnitude,0.7,'AbsTol',1e-14);
end

function testFFTUnaMuestraMulticanal(testCase)
[f,magnitude] = calcularFFT([0.2 -0.4 0.6],8000);
verifyEqual(testCase,f,0);
verifySize(testCase,magnitude,[1 3]);
verifyEqual(testCase,magnitude,[0.2 0.4 0.6],'AbsTol',1e-14);
end

function testFFTSilencioEsFinita(testCase)
[f,magnitude] = calcularFFT(zeros(33,2),44100);
verifySize(testCase,magnitude,[17 2]);
verifyEqual(testCase,magnitude,zeros(17,2));
verifyTrue(testCase,all(isfinite(f(:))) && all(isfinite(magnitude(:))));
end
