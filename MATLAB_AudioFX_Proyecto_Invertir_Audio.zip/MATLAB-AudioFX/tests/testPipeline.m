function tests = testPipeline
%TESTPIPELINE Cadena, metadatos y protección global contra clipping.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
root = fileparts(fileparts(mfilename('fullpath')));
testCase.TestData.oldPath = path;
addpath(fullfile(root,'src'),fullfile(root,'effects'),fullfile(root,'analysis'));
end

function teardownOnce(testCase)
path(testCase.TestData.oldPath);
end

function testValoresInicialesConservanAudio(testCase)
p = parametrosPorDefecto();
x = [0.1 -0.2; 0.3 0.5; -0.4 0.2];
[y,FsOut,info] = procesarCadena(x,8000,p);
verifyEqual(testCase,y,x);
verifyEqual(testCase,FsOut,8000);
verifyEqual(testCase,info.muestrasEntrada,3);
verifyEqual(testCase,info.muestrasSalida,3);
verifyEqual(testCase,info.canales,2);
verifyEqual(testCase,info.duracionEntrada,3/8000,'AbsTol',1e-14);
verifyEqual(testCase,info.duracionSalida,3/8000,'AbsTol',1e-14);
verifyFalse(testCase,info.recorteNecesario);
end

function testCadenaRespetaOrdenDefinido(testCase)
Fs = 8000; t = (0:999)'/Fs;
x = [0.3*sin(2*pi*300*t) 0.2*cos(2*pi*500*t)];
p = parametrosPorDefecto();
p.ganancia = 1.4;
p.ecoActivo = true; p.delaySeg = 0.02; p.alpha = 0.3;
p.distorsionActiva = true; p.intensidad = 2;
p.filtroActivo = true; p.tipoFiltro = 'pasabajos'; p.fc = 1500;
p.velocidad = 1.25;
expected = aplicarGanancia(x,p.ganancia);
expected = aplicarEco(expected,Fs,p.delaySeg,p.alpha);
expected = aplicarDistorsion(expected,p.intensidad);
expected = aplicarFiltro(expected,Fs,p.tipoFiltro,p.fc,p.orden);
[expected,expectedFs] = cambiarVelocidad(expected,Fs,p.velocidad);
[y,FsOut,info] = procesarCadena(x,Fs,p);
verifyEqual(testCase,y,expected,'AbsTol',1e-12);
verifyEqual(testCase,FsOut,expectedFs);
verifyEqual(testCase,info.muestrasSalida,size(y,1));
verifyTrue(testCase,all(isfinite(y(:))));
end

function testReprocesarOriginalEsReproducible(testCase)
x = linspace(-0.3,0.3,200)'; p = parametrosPorDefecto(); p.ganancia = 2;
[first,~] = procesarCadena(x,8000,p);
[second,~] = procesarCadena(x,8000,p);
verifyEqual(testCase,first,second);
verifyEqual(testCase,x,linspace(-0.3,0.3,200)');
end

function testCadenaDetectaClippingSinAlterarEfecto(testCase)
x = [0.8 -0.2; -0.6 0.4]; p = parametrosPorDefecto(); p.ganancia = 2;
[y,~,info] = procesarCadena(x,8000,p);
verifyEqual(testCase,y,2*x);
verifyTrue(testCase,info.recorteNecesario);
verifyEqual(testCase,info.picoEntrada,0.8,'AbsTol',1e-14);
verifyEqual(testCase,info.picoSalida,1.6,'AbsTol',1e-14);
end

function testNormalizacionGlobalConservaRelacionCanales(testCase)
x = [2 0.5; -1 0.25];
[y,factor,pico] = prepararSalida(x);
verifyEqual(testCase,pico,2);
verifyEqual(testCase,factor,0.5);
verifyEqual(testCase,y,0.5*x);
verifyLessThanOrEqual(testCase,max(abs(y(:))),1);
end

function testNormalizacionNoAmplificaSilencioNiAudioValido(testCase)
[silence,factor,pico] = prepararSalida(zeros(8,2));
verifyEqual(testCase,silence,zeros(8,2));
verifyEqual(testCase,[factor pico],[1 0]);
x = [0.1; -0.7];
[y,factor,pico] = prepararSalida(x);
verifyEqual(testCase,y,x);
verifyEqual(testCase,[factor pico],[1 0.7],'AbsTol',1e-14);
end

function testPicoUnidadNoReescala(testCase)
x = [1 -0.5; 0.2 -1];
[y,factor,pico] = prepararSalida(x);
verifyEqual(testCase,y,x);
verifyEqual(testCase,[factor pico],[1 1]);
end

function testCadenaSilencioConTodosLosEfectos(testCase)
p = parametrosPorDefecto();
p.ecoActivo = true; p.distorsionActiva = true; p.filtroActivo = true;
p.fc = 1000; p.velocidad = 0.5;
[y,FsOut] = procesarCadena(zeros(400,2),8000,p);
verifyEqual(testCase,y,zeros(size(y)));
verifyEqual(testCase,FsOut,8000);
verifyTrue(testCase,all(isfinite(y(:))));
end
