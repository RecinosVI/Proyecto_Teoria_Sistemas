param([string]$ProjectRoot = (Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$checks = [Collections.Generic.List[string]]::new()
function Check($condition,$label) {
    if (-not $condition) { throw "Fallo: $label" }
    $checks.Add($label)
}
$effect = Get-Content (Join-Path $ProjectRoot 'effects/invertirAudio.m') -Raw
Check ($effect.Contains('validarAudio(x)') -and $effect.Contains('flip(x,1)')) 'Contrato: validar entrada e invertir dimensión temporal'
$chain = Get-Content (Join-Path $ProjectRoot 'src/procesarCadena.m') -Raw
Check ($chain.IndexOf('y = invertirAudio(y)') -gt $chain.IndexOf('[y,FsSalida] = cambiarVelocidad')) 'Inversión después de velocidad'
Check ($chain.Contains("if ~isfield(p,'invertirActivo'), p.invertirActivo = false; end")) 'Compatibilidad con configuraciones anteriores'
$source = Get-Content (Join-Path $ProjectRoot 'resources/source/AudioFX.m') -Raw
Check ($source.Contains("app.InvertCheck.Text = 'Invertir audio'")) 'Etiqueta de interfaz'
Check ($source.Contains('p.invertirActivo = app.InvertCheck.Value;')) 'Lectura de casilla en parámetros'
Check ($source.Contains('app.InvertCheck.Value = p.invertirActivo;')) 'Restablecimiento de casilla'
Check ($source.Contains('app.InvertCheck.ValueChangedFcn = createCallbackFcn(app, @ParameterChanged, true);')) 'Conexión del callback de invalidación'
$zip = [IO.Compression.ZipFile]::OpenRead((Join-Path $ProjectRoot 'app/AudioFX.mlapp'))
try {
    $entry = $zip.Entries | Where-Object FullName -eq 'matlab/document.xml'
    Check ($null -ne $entry) 'MLAPP contiene documento de código'
    $reader = [IO.StreamReader]::new($entry.Open())
    try { $xml = $reader.ReadToEnd() } finally { $reader.Dispose() }
    Check ($xml.Contains('InvertCheck') -and $xml.Contains('invertirActivo')) 'MLAPP contiene el sexto efecto'
    Check (($zip.Entries | Where-Object FullName -eq 'appdesigner/appModel.mat').Count -eq 1) 'MLAPP conserva modelo nativo de App Designer'
} finally { $zip.Dispose() }
Check ((Test-Path (Join-Path $ProjectRoot 'MATLAB-AudioFX.prj'))) 'Descriptor del proyecto presente'
Check ((Select-String -Path (Join-Path $ProjectRoot 'tests/testInvertirAudio.m') -CaseSensitive -Pattern '^function test[A-Z]').Count -eq 8) 'Ocho pruebas nuevas disponibles'
[pscustomobject]@{tipo='Inspección estática sin ejecutar MATLAB'; aprobadas=$checks.Count; comprobaciones=$checks} | ConvertTo-Json -Depth 4
