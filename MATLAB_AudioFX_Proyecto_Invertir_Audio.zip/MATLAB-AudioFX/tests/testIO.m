function tests = testIO
%TESTIO Round-trip WAV sin tocar audios del usuario ni usar altavoces.
tests = functiontests(localfunctions);
end

function setupOnce(testCase)
root = fileparts(fileparts(mfilename('fullpath')));
testCase.TestData.oldPath = path;
testCase.TestData.root = root;
addpath(fullfile(root,'src'),fullfile(root,'effects'),fullfile(root,'analysis'));
end

function teardownOnce(testCase)
path(testCase.TestData.oldPath);
end

function testAudioDePruebaTieneMetadatosValidos(testCase)
ruta = fullfile(testCase.TestData.root,'audio','prueba.wav');
[x,Fs,info] = cargarAudio(ruta);
verifyGreaterThan(testCase,size(x,1),0);
verifyGreaterThan(testCase,Fs,0);
verifyEqual(testCase,info.muestras,size(x,1));
verifyEqual(testCase,info.canales,size(x,2));
verifyEqual(testCase,info.duracion,size(x,1)/Fs,'AbsTol',1e-12);
verifyTrue(testCase,all(isfinite(x(:))));
end

function testExportarYCargarEstereo(testCase)
ruta = [tempname '.wav']; cleanup = onCleanup(@() deleteIfExists(ruta)); %#ok<NASGU>
Fs = 8000; t = (0:799)'/Fs;
x = [0.4*sin(2*pi*400*t) 0.2*cos(2*pi*700*t)];
info = exportarAudio(x,Fs,ruta);
[loaded,loadedFs] = audioread(ruta);
verifyEqual(testCase,loadedFs,Fs);
verifySize(testCase,loaded,size(x));
verifyEqual(testCase,loaded,x,'AbsTol',2/2^23);
verifyFalse(testCase,info.normalizado);
metadata = audioinfo(ruta);
verifyEqual(testCase,metadata.BitsPerSample,24);
end

function testExportarNormalizaPicoGlobal(testCase)
ruta = [tempname '.wav']; cleanup = onCleanup(@() deleteIfExists(ruta)); %#ok<NASGU>
x = [2 0.5; -1 -0.25; 0.2 0.1];
info = exportarAudio(x,8000,ruta);
[loaded,Fs] = audioread(ruta);
verifyEqual(testCase,Fs,8000);
verifyEqual(testCase,loaded,x/2,'AbsTol',2/2^23);
verifyEqual(testCase,info.factorAplicado,0.5,'AbsTol',1e-14);
verifyEqual(testCase,info.picoOriginal,2,'AbsTol',1e-14);
verifyTrue(testCase,info.normalizado);
verifyLessThanOrEqual(testCase,max(abs(loaded(:))),1);
end

function testExportarSilencioMono(testCase)
ruta = [tempname '.wav']; cleanup = onCleanup(@() deleteIfExists(ruta)); %#ok<NASGU>
info = exportarAudio(zeros(100,1),8000,ruta);
[loaded,Fs] = audioread(ruta);
verifyEqual(testCase,loaded,zeros(100,1));
verifyEqual(testCase,Fs,8000);
verifyEqual(testCase,info.factorAplicado,1);
verifyFalse(testCase,info.normalizado);
end

function deleteIfExists(ruta)
if isfile(ruta), delete(ruta); end
end
