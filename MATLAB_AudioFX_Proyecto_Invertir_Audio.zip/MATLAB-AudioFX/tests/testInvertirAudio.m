function tests = testInvertirAudio
%TESTINVERTIRAUDIO Contrato temporal, canales, validación e integración.
tests = functiontests(localfunctions);
end
function setupOnce(t)
root = fileparts(fileparts(mfilename('fullpath')));
t.TestData.oldPath = path;
addpath(fullfile(root,'src'),fullfile(root,'effects'));
end
function teardownOnce(t)
path(t.TestData.oldPath);
end
function testMono(t)
verifyEqual(t,invertirAudio([0.1; -0.4; 0.8]),[0.8; -0.4; 0.1]);
end
function testEstereoSinIntercambiarCanales(t)
x = [1 10; 2 20; 3 30; 4 40];
verifyEqual(t,invertirAudio(x),[4 40; 3 30; 2 20; 1 10]);
verifyEqual(t,invertirAudio(invertirAudio(x)),x);
end
function testUnaMuestraYSilencio(t)
verifyEqual(t,invertirAudio([0.2 -0.8]),[0.2 -0.8]);
verifyEqual(t,invertirAudio(zeros(7,2)),zeros(7,2));
verifyEqual(t,invertirAudio(single([1; 2])),[2; 1]);
end
function testEntradasInvalidas(t)
for x = {[], 'audio', 1i, sparse(eye(2)), ones(2,2,2)}
    verifyError(t,@() invertirAudio(x{1}),'AudioFX:AudioInvalido');
end
for x = {[NaN; 1], [1 Inf]}
    verifyError(t,@() invertirAudio(x{1}),'AudioFX:AudioNoFinito');
end
end
function testCadenaYMetadatos(t)
x = [0.1 -0.2; 0.3 0.4; -0.5 0.6];
p = parametrosPorDefecto();
verifyFalse(t,p.invertirActivo);
p.invertirActivo = true;
[y,fs,info] = procesarCadena(x,8000,p);
verifyEqual(t,y,x(end:-1:1,:));
verifyEqual(t,fs,8000);
verifyEqual(t,info.muestrasSalida,3);
verifyEqual(t,info.canales,2);
verifyEqual(t,info.duracionSalida,3/8000);
verifyEqual(t,info.ordenCadena,{'ganancia','velocidad','invertir'});
verifyEqual(t,x,[0.1 -0.2; 0.3 0.4; -0.5 0.6]);
end
function testConfiguracionAnterior(t)
p = rmfield(parametrosPorDefecto(),'invertirActivo');
x = [0.1; 0.2; 0.3];
verifyEqual(t,procesarCadena(x,8000,p),x);
end
function testIndicadorInvalido(t)
p = parametrosPorDefecto();
for v = {2, NaN, [true false], 'si', 1i}
    p.invertirActivo = v{1};
    verifyError(t,@() procesarCadena([0.1; 0.2],8000,p),'AudioFX:Parametros');
end
end
function testInversionDespuesDeTodosLosEfectos(t)
x = [linspace(-0.4,0.5,400)' linspace(0.3,-0.2,400)'];
p = parametrosPorDefecto();
p.ganancia = 1.3; p.ecoActivo = true; p.delaySeg = 0.01;
p.distorsionActiva = true; p.filtroActivo = true; p.fc = 1000;
p.velocidad = 1.25;
[antes,fs] = procesarCadena(x,8000,p);
p.invertirActivo = true;
[y,fsOut,info] = procesarCadena(x,8000,p);
verifyEqual(t,y,antes(end:-1:1,:));
verifyEqual(t,fsOut,fs);
verifyEqual(t,info.ordenCadena,{'ganancia','eco','distorsion','filtro','velocidad','invertir'});
end
