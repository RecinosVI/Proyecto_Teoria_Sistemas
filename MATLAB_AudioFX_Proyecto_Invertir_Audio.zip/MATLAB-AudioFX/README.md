# MATLAB AudioFX

Proyecto de procesamiento y análisis de audio con aplicación nativa de App Designer, seis efectos, comparación temporal y FFT, reproducción y exportación WAV. La entrega incluye `MATLAB-AudioFX.prj` y `app/AudioFX.mlapp` generados y ejecutados en MATLAB R2026b.

**Actualización Invertir audio (15 de octubre de 2026):** 52 pruebas MATLAB aprobadas (ocho nuevas), 33 comprobaciones programáticas sobre la app nativa y 12 comprobaciones estáticas sin MATLAB. Se regeneraron `AudioFX.mlapp` y el proyecto con MATLAB R2026b. Evidencia actual: `docs/verificacion_invertir_audio.json` y `docs/verificacion_sin_matlab_invertir.json`.

Marque **Invertir audio** y pulse **Procesar** para invertir el tiempo sin intercambiar canales. Está desactivado por defecto y se aplica al final de la cadena. Consulte `docs/ACTUALIZACION_INVERTIR_AUDIO.md` para cambios, reproducción de verificaciones y pendientes.

Los otros informes, capturas y audios del paquete original se conservan como evidencia histórica de la versión anterior. No certifican la nueva casilla. Para esta actualización quedan pendientes la escucha humana, los diálogos reales de carga/exportación y la revisión y guardado manual desde App Designer.

## Abrir y usar

1. Descomprimir el paquete completo conservando sus carpetas.
2. Abrir `MATLAB-AudioFX.prj` en MATLAB R2026b. El proyecto configura las rutas de sus módulos.
3. Ejecutar el acceso directo **Iniciar AudioFX**, o escribir desde la raíz:

```matlab
iniciarAudioFX
```

También se puede abrir `app/AudioFX.mlapp` en App Designer y pulsar **Run** con el proyecto abierto.

4. Pulsar **Cargar WAV**, elegir `audio/prueba.wav`, configurar los efectos y pulsar **Procesar**. Las pestañas muestran el original y el resultado en tiempo y frecuencia. Los botones permiten escucharlos, detener la reproducción, exportar el WAV y restablecer los controles.

Necesita MATLAB y Signal Processing Toolbox para los filtros y el remuestreo. Audio Toolbox y DSP System Toolbox son compatibles con el entorno previsto; los módulos no dependen de ellos. La frecuencia de salida se conserva al cambiar velocidad; por eso también cambia el tono.

## Contenido entregado

- `MATLAB-AudioFX.prj` y `resources/project/`: proyecto MATLAB y sus metadatos.
- `app/AudioFX.mlapp`: aplicación nativa con 49 componentes identificados y nueve callbacks.
- `effects/`: ganancia, eco, distorsión, filtros, velocidad e inversión temporal.
- `analysis/`: FFT unilateral por canal y gráfica temporal.
- `src/`: carga, cadena de procesamiento, salida segura, exportación y demostración.
- `tests/`: 52 pruebas numéricas y de entrada/salida.
- `resources/source/AudioFX.m`: respaldo de la fuente de la interfaz; no se añade al MATLAB Path.
- `audio/prueba.wav`: señal sintética propia, estéreo, 3 s a 48 kHz.
- `audio/resultado_demo.wav`: resultado de la cadena completa generado y exportado por MATLAB, estéreo, 2.6 s a 48 kHz.
- `audio/prueba_procesado.wav`: exportación PCM24 obtenida con el botón **Exportar WAV** y su cuadro Guardar.
- `audio/resultado_referencia.wav`: referencia independiente de ganancia 0.5; complementa la evidencia MATLAB.
- `docs/comparacion_tiempo.png`, `docs/comparacion_fft.png`: gráficas de la demostración MATLAB.
- `docs/interfaz_tiempo.png`, `docs/interfaz_fft.png`: capturas de la aplicación nativa.
- `docs/verificacion_matlab.json`, `docs/verificacion_callbacks_audio.json`: resultados reales de ejecución.
- `docs/`: manual, arquitectura, teoría, trazabilidad, demostración y estado de la entrega.
- `.git/`: historial del repositorio local; `.gitignore` excluye temporales y cachés.

## Repetir las verificaciones

Desde la raíz del proyecto:

```matlab
addpath('tests');
results = run_tests;
addpath('src');
informeGUI = verificarApp;
datos = generarDemostracion;
```

`verificarApp` comprueba carga, estado, gráficas, controles y exportación; no reproduce audio. Los resultados de reproducción de esta entrega están en `docs/verificacion_callbacks_audio.json`.

`generarEntregables` permite regenerar las pruebas, aplicación, demostración y proyecto. Los generadores de App Designer usan APIs internas de R2026b; su compatibilidad con otras versiones no está garantizada. El respaldo de la fuente permite mantener el proyecto.

El manual explica todos los controles y la matriz relaciona cada requisito con su implementación y evidencia. `docs/ESTADO_ENTREGA.md` distingue la verificación técnica terminada de la publicación externa y la evaluación perceptiva humana.
